# =============================================================
#  create_owner.py — One-Time Owner Setup Script
#  FILE: webguard-backend/create_owner.py
#
#  RUN ONCE ONLY: python create_owner.py
#  Running again will say "Owner already exists."
#
#  What this does:
#   1. Reads OWNER_EMAIL + OWNER_PASSWORD from .env
#   2. Creates the owner account with bcrypt-hashed password
#   3. Generates a random TOTP secret (pyotp)
#   4. Saves a QR code image → owner_2fa_qr.png
#   5. Scan QR with Google Authenticator or Authy
#
#  AFTER SETUP:
#   - Delete owner_2fa_qr.png (it's in .gitignore already)
#   - Save the backup TOTP secret in your password manager
# =============================================================

import os
import sys
import bcrypt
import pyotp
import qrcode
from dotenv import load_dotenv

from app import create_app
from models import db, User

load_dotenv()


def main():
    app = create_app()
    with app.app_context():

        if User.query.filter_by(role="owner").first():
            print("[!] Owner already exists. Exiting.")
            sys.exit(0)

        email    = os.environ.get("OWNER_EMAIL")
        password = os.environ.get("OWNER_PASSWORD")

        if not email or not password:
            print("[ERROR] Set OWNER_EMAIL and OWNER_PASSWORD in .env first.")
            sys.exit(1)

        pw_hash = bcrypt.hashpw(
            password.encode("utf-8"),
            bcrypt.gensalt(rounds=12),
        ).decode("utf-8")

        # Random 32-char base32 string — the seed for TOTP codes
        totp_secret = pyotp.random_base32()

        owner = User(
            email=email,
            password_hash=pw_hash,
            role="owner",
            disclaimer_accepted=True,
            totp_secret=totp_secret,
        )
        db.session.add(owner)
        db.session.commit()

        print(f"\n[+] Owner created: {email}")
        print(f"[+] UUID: {owner.id}")

        # Build the QR code URI for Google Authenticator
        uri = pyotp.TOTP(totp_secret).provisioning_uri(
            name=email,
            issuer_name="WebGuard Scanner",
        )

        qr = qrcode.QRCode(box_size=10, border=4)
        qr.add_data(uri)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        img.save("owner_2fa_qr.png")

        print("\n[+] QR code saved → owner_2fa_qr.png")
        print("[!] Scan it with Google Authenticator or Authy NOW.")
        print("[!] Then DELETE the file — never commit it to Git.")
        print(f"\n[i] Backup TOTP secret: {totp_secret}")
        print("[!] Save this in your password manager.\n")


if __name__ == "__main__":
    main()
