# =============================================================
#  app.py — WebGuard Scanner: Main Flask Application
#  FILE: webguard-backend/app.py
# =============================================================
#
#  This file does everything:
#   1. Creates and configures the Flask app
#   2. Applies security headers to every response (after_request)
#   3. Runs auto-ban threat detection before every request (before_request)
#   4. Defines all 15 API endpoints
#
#  Key security rules enforced here:
#   a) No stack traces ever — custom error handlers only
#   b) All secrets from .env — nothing hardcoded
#   c) bcrypt for passwords — never MD5/SHA1/plain
#   d) Fernet AES for scan data — encrypted before DB storage
#   e) UUID primary keys — prevents enumeration
#   f) SQLAlchemy ORM — parameterized queries, no raw SQL
#   g) SSRF guard — internal IPs blocked from scan endpoint
#   h) Rate limiting — brute force and scan abuse prevention
# =============================================================

import os
import re
import json
import uuid
import pyotp
import bcrypt
from functools import wraps
from datetime import datetime, timedelta, timezone

from flask import Flask, request, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, login_user, logout_user,
    login_required, current_user,
)
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_cors import CORS
from flask_mail import Mail, Message
from cryptography.fernet import Fernet
from dotenv import load_dotenv

from models import db, User, ScanHistory, BannedUser, BannedIP, SecurityIncident
from scanner.checks import run_surface_scan
from scanner.deep_checks import run_deep_scan

load_dotenv()  # Load .env before anything else touches os.environ


# =============================================================
#  App Factory Function
# =============================================================
def create_app():
    app = Flask(__name__)

    # ----------------------------------------------------------
    #  Core Config
    # ----------------------------------------------------------
    secret = os.environ.get("SECRET_KEY", "")
    if not secret:
        raise RuntimeError("SECRET_KEY missing from .env — refusing to start.")
    app.config["SECRET_KEY"] = secret

    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///webguard.db"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # Session cookie hardening
    # HttpOnly  → JS cannot steal session cookie
    # SameSite  → CSRF protection
    # Secure    → cookies only sent over HTTPS (production only)
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    app.config["SESSION_COOKIE_SECURE"] = (
        os.environ.get("FLASK_ENV") == "production"
    )
    app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=2)

    # Flask-Mail
    app.config["MAIL_SERVER"]   = os.environ.get("MAIL_SERVER", "smtp.gmail.com")
    app.config["MAIL_PORT"]     = int(os.environ.get("MAIL_PORT", 587))
    app.config["MAIL_USE_TLS"]  = os.environ.get("MAIL_USE_TLS", "True") == "True"
    app.config["MAIL_USERNAME"] = os.environ.get("MAIL_USERNAME")
    app.config["MAIL_PASSWORD"] = os.environ.get("MAIL_PASSWORD")
    app.config["MAIL_DEFAULT_SENDER"] = os.environ.get("MAIL_USERNAME")

    # ----------------------------------------------------------
    #  Init Extensions
    # ----------------------------------------------------------
    db.init_app(app)
    mail = Mail(app)

    login_manager = LoginManager(app)
    # "strong" → Flask-Login invalidates session if IP/browser changes
    login_manager.session_protection = "strong"

    enc_key = os.environ.get("ENCRYPTION_KEY", "")
    if not enc_key:
        raise RuntimeError("ENCRYPTION_KEY missing from .env — refusing to start.")
    fernet = Fernet(enc_key.encode())

    # Rate limiter — stored in memory (use Redis in production for multi-worker)
    limiter = Limiter(
        get_remote_address,
        app=app,
        default_limits=["200 per day", "50 per hour"],
        storage_uri="memory://",
    )

    # CORS — only allow your React frontend
    # supports_credentials=True is required for session cookies to work cross-origin
    CORS(app, resources={r"/api/*": {
        "origins": [
            "http://localhost:5173",                      # Vite dev
            "https://your-app.lovable.app",               # Replace with real URL
        ],
        "supports_credentials": True,
    }})

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(user_id)

    # ----------------------------------------------------------
    #  Unauthorised handler (replaces default redirect)
    # ----------------------------------------------------------
    @login_manager.unauthorized_handler
    def unauthorized():
        return jsonify({"error": "Authentication required."}), 401

    # ==========================================================
    #  SECURITY HEADERS — every single response
    # ==========================================================
    @app.after_request
    def set_security_headers(response):
        # Clickjacking protection
        response.headers["X-Frame-Options"] = "DENY"
        # MIME-sniffing protection
        response.headers["X-Content-Type-Options"] = "nosniff"
        # Force HTTPS for 1 year (browsers cache this)
        response.headers["Strict-Transport-Security"] = (
            "max-age=31536000; includeSubDomains"
        )
        # Don't leak referrer to other sites
        response.headers["Referrer-Policy"] = "no-referrer"
        # Restrict browser APIs the app can use
        response.headers["Permissions-Policy"] = (
            "geolocation=(), microphone=(), camera=()"
        )
        # CSP — only load scripts/styles from our own origin
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; "
            "connect-src 'self'"
        )
        # NEVER expose Flask or Werkzeug version to attackers
        response.headers["Server"] = "WebGuard"
        return response

    # ==========================================================
    #  AUTO-BAN THREAT DETECTION
    # ==========================================================

    # SQL injection signatures — covers classic and advanced patterns
    _SQLI = re.compile(
        r"(\b(union\s+select|drop\s+table|insert\s+into|exec\s*\(|"
        r"xp_cmdshell|information_schema)\b"
        r"|'\s*(or|and)\s*'?\d'?\s*=\s*'?\d"
        r"|--\s*$|;\s*drop\b)",
        re.IGNORECASE,
    )

    # Paths attackers probe looking for config/credential files
    _SENSITIVE = re.compile(
        r"^(/\.env|/\.git|/config|/database|/backup|/db\.sqlite|/wp-config)",
        re.IGNORECASE,
    )

    def _ip() -> str:
        """Get real client IP, respecting reverse proxies."""
        return (
            request.headers.get("X-Forwarded-For", request.remote_addr)
            .split(",")[0]
            .strip()
        )

    def _ban(user_id, ip, reason, incident_type, details):
        """
        Permanently ban a user account and IP.
        Logs a full SecurityIncident record.
        Always clears the current session.
        """
        inc = SecurityIncident(
            user_id=user_id,
            ip_address=ip,
            incident_type=incident_type,
            details=details,
        )
        db.session.add(inc)

        if user_id:
            u = User.query.get(user_id)
            if u and not u.is_banned:
                u.is_banned = True
                db.session.add(BannedUser(user_id=user_id, reason=reason))

        if not BannedIP.query.filter_by(ip_address=ip).first():
            db.session.add(BannedIP(ip_address=ip, reason=reason))

        db.session.commit()
        session.clear()

    def _suspended():
        """Standard opaque response — never reveals the detection reason."""
        return jsonify({"error": "Account suspended."}), 403

    @app.before_request
    def threat_detection():
        ip = _ip()

        # 1. Banned IP check
        if BannedIP.query.filter_by(ip_address=ip).first():
            return _suspended()

        # 2. Banned user check
        if current_user.is_authenticated and current_user.is_banned:
            session.clear()
            return _suspended()

        # 3. Sensitive path probing (/.env, /.git, etc.)
        if _SENSITIVE.search(request.path):
            uid = current_user.id if current_user.is_authenticated else None
            _ban(uid, ip, "Sensitive path probe", "PATH_PROBE",
                 f"Path: {request.path}")
            return _suspended()

        # 4. SQL injection in query string
        for k, v in request.args.items():
            if _SQLI.search(str(v)) or _SQLI.search(str(k)):
                uid = current_user.id if current_user.is_authenticated else None
                _ban(uid, ip, "SQL injection in query string", "SQL_INJECTION",
                     f"{k}={str(v)[:200]}")
                return _suspended()

        # 5. SQL injection in JSON body
        if request.is_json:
            body = request.get_json(silent=True) or {}
            for k, v in body.items():
                if _SQLI.search(str(v)) or _SQLI.search(str(k)):
                    uid = current_user.id if current_user.is_authenticated else None
                    _ban(uid, ip, "SQL injection in request body", "SQL_INJECTION",
                         f"key={k} value={str(v)[:200]}")
                    return _suspended()

        # 6. history_verified must be exactly boolean True
        #    Anything else = someone tampered with the session cookie
        if "history_verified" in session:
            if session.get("history_verified") is not True:
                uid = current_user.id if current_user.is_authenticated else None
                _ban(uid, ip, "Session tampering", "SESSION_TAMPER",
                     "history_verified was not boolean True")
                return _suspended()

        # 7. Auto-expire history_verified after 10 minutes
        if session.get("history_verified"):
            ts = session.get("history_verified_at")
            if ts:
                dt = datetime.fromisoformat(ts)
                if datetime.now(timezone.utc) - dt > timedelta(minutes=10):
                    session.pop("history_verified", None)
                    session.pop("history_verified_at", None)

    # ==========================================================
    #  SSRF PROTECTION HELPER
    # ==========================================================
    _INTERNAL_IP = re.compile(
        r"^(127\.|192\.168\.|10\.|172\.(1[6-9]|2\d|3[0-1])\.|"
        r"localhost|0\.0\.0\.0|::1)",
        re.IGNORECASE,
    )

    def _is_ssrf(url: str) -> bool:
        """
        Returns True if the URL resolves to an internal/private network.
        WHY: without this, an attacker could scan 192.168.1.1 (the router)
        or internal servers through WebGuard's outbound connection.
        We check BOTH the raw hostname AND the resolved IP.
        """
        from urllib.parse import urlparse
        import socket
        try:
            host = urlparse(url).hostname or ""
            if _INTERNAL_IP.search(host):
                return True
            resolved = socket.gethostbyname(host)
            if _INTERNAL_IP.search(resolved):
                return True
        except Exception:
            pass
        return False

    # ==========================================================
    #  OWNER-ONLY DECORATOR
    # ==========================================================
    def require_owner_2fa(f):
        """
        Protects owner routes. Checks all four conditions:
          1. User is logged in
          2. User role is 'owner'
          3. owner_2fa_verified is True in session
          4. Session has not expired (15 min) and IP hasn't changed
        """
        @wraps(f)
        def decorated(*args, **kwargs):
            if not current_user.is_authenticated:
                return jsonify({"error": "Authentication required."}), 401
            if current_user.role != "owner":
                return jsonify({"error": "Not found."}), 404
            if not session.get("owner_2fa_verified"):
                return jsonify({"error": "2FA verification required."}), 403
            ts = session.get("owner_2fa_verified_at")
            if ts:
                dt = datetime.fromisoformat(ts)
                if datetime.now(timezone.utc) - dt > timedelta(minutes=15):
                    session.pop("owner_2fa_verified", None)
                    return jsonify({"error": "Owner session expired. Re-verify 2FA."}), 403
            if session.get("owner_session_ip") != _ip():
                session.clear()
                return jsonify({"error": "Session IP mismatch. Log in again."}), 403
            return f(*args, **kwargs)
        return decorated

    # ==========================================================
    #  CUSTOM ERROR HANDLERS
    #  Default Flask errors show stack traces — we never do that
    # ==========================================================
    @app.errorhandler(400)
    def bad_request(_):
        return jsonify({"error": "Bad request."}), 400

    @app.errorhandler(404)
    def not_found(_):
        return jsonify({"error": "Not found."}), 404

    @app.errorhandler(405)
    def method_not_allowed(_):
        return jsonify({"error": "Method not allowed."}), 405

    @app.errorhandler(429)
    def rate_limited(_):
        return jsonify({"error": "Too many requests. Please slow down."}), 429

    @app.errorhandler(500)
    def internal_error(_):
        # NEVER include exception details here
        return jsonify({"error": "An internal error occurred."}), 500

    # ==========================================================
    #  AUTH ROUTES
    # ==========================================================

    @app.route("/api/auth/register", methods=["POST"])
    @limiter.limit("10 per hour")
    def register():
        data = request.get_json(silent=True) or {}
        email    = str(data.get("email", "")).strip().lower()
        password = str(data.get("password", ""))

        if not email or not password:
            return jsonify({"error": "Email and password are required."}), 400

        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
            return jsonify({"error": "Invalid email format."}), 400

        # Minimum password strength: 8 chars, 1 uppercase, 1 digit
        if (len(password) < 8
                or not re.search(r"[A-Z]", password)
                or not re.search(r"\d", password)):
            return jsonify({
                "error": "Password must be 8+ chars with 1 uppercase and 1 number."
            }), 400

        # Parameterized query via ORM — never raw SQL
        if User.query.filter_by(email=email).first():
            return jsonify({"error": "Email already registered."}), 409

        # bcrypt with cost factor 12 — slow enough to resist brute force
        pw_hash = bcrypt.hashpw(
            password.encode("utf-8"),
            bcrypt.gensalt(rounds=12),
        ).decode("utf-8")

        user = User(email=email, password_hash=pw_hash, role="user")
        db.session.add(user)
        db.session.commit()
        return jsonify({"message": "Account created. Please log in."}), 201

    @app.route("/api/auth/login", methods=["POST"])
    @limiter.limit("20 per hour")
    def login():
        data = request.get_json(silent=True) or {}
        email    = str(data.get("email", "")).strip().lower()
        password = str(data.get("password", ""))
        ip       = _ip()

        user = User.query.filter_by(email=email).first()

        # Same error message whether email exists or not
        # WHY: different messages allow attackers to enumerate valid emails
        BAD = {"error": "Invalid credentials."}

        if not user:
            return jsonify(BAD), 401

        if user.is_banned:
            return jsonify({"error": "Account suspended."}), 403

        if not bcrypt.checkpw(password.encode(), user.password_hash.encode()):
            user.failed_login_count += 1
            db.session.commit()
            if user.failed_login_count >= 10:
                _ban(user.id, ip,
                     "10+ failed logins", "BRUTE_FORCE_LOGIN",
                     f"Count: {user.failed_login_count}")
                return jsonify({"error": "Account suspended."}), 403
            return jsonify(BAD), 401

        # Password correct — reset counter
        user.failed_login_count = 0
        db.session.commit()

        # Owner: send to 2FA step — do NOT create full session yet
        if user.role == "owner":
            if user.two_fa_locked_until:
                lock = datetime.fromisoformat(user.two_fa_locked_until).replace(
                    tzinfo=timezone.utc
                )
                if datetime.now(timezone.utc) < lock:
                    mins = int((lock - datetime.now(timezone.utc)).total_seconds() / 60)
                    return jsonify({"error": f"2FA locked. Try in {mins} min."}), 403
            session["pre_2fa_user_id"] = user.id
            return jsonify({"message": "Password correct. 2FA required.",
                            "requires_2fa": True}), 200

        login_user(user, remember=False)
        session.permanent = True
        return jsonify({
            "message": "Login successful.",
            "user": {
                "id": user.id,
                "email": user.email,
                "disclaimer_accepted": user.disclaimer_accepted,
            },
        }), 200

    @app.route("/api/auth/logout", methods=["POST"])
    def logout():
        logout_user()
        session.clear()  # Wipe ALL session keys including custom ones
        return jsonify({"message": "Logged out."}), 200

    @app.route("/api/auth/disclaimer", methods=["POST"])
    @login_required
    def accept_disclaimer():
        current_user.disclaimer_accepted = True
        db.session.commit()
        return jsonify({"message": "Disclaimer accepted."}), 200

    # ==========================================================
    #  SCAN ROUTE
    # ==========================================================

    @app.route("/api/scan", methods=["POST"])
    @login_required
    @limiter.limit("5 per hour")
    def run_scan():
        if not current_user.disclaimer_accepted:
            return jsonify({
                "error": "You must accept the ethical use disclaimer before scanning."
            }), 403

        data = request.get_json(silent=True) or {}
        target = str(data.get("url", "")).strip()

        if not target:
            return jsonify({"error": "URL is required."}), 400

        if not re.match(r"^https?://", target, re.I):
            return jsonify({"error": "URL must start with http:// or https://"}), 400

        # SSRF protection — block scans targeting internal network
        if _is_ssrf(target):
            _ban(current_user.id, _ip(),
                 "SSRF scan attempt", "SSRF_ATTEMPT",
                 f"Target: {target}")
            return jsonify({"error": "Account suspended."}), 403

        # Run both scan types
        surface = run_surface_scan(target)
        deep    = run_deep_scan(target)

        all_findings = surface.get("findings", []) + deep.get("findings", [])
        final_score  = max(0, surface.get("score", 100) - deep.get("score_deduction", 0))

        result = {
            "url":          target,
            "scan_date":    datetime.utcnow().isoformat(),
            "surface":      surface,
            "deep":         deep,
            "all_findings": all_findings,
            "final_score":  final_score,
        }

        # Fernet encrypt before storing — AES-128-CBC + HMAC
        encrypted = fernet.encrypt(json.dumps(result).encode()).decode()

        record = ScanHistory(
            user_id=current_user.id,
            target_url=target,
            encrypted_result=encrypted,
        )
        db.session.add(record)
        db.session.commit()

        return jsonify({"scan_id": record.id, "result": result}), 200

    # ==========================================================
    #  HISTORY ROUTES
    # ==========================================================

    @app.route("/api/history/verify-password", methods=["POST"])
    @login_required
    @limiter.limit("10 per hour")
    def history_verify_password():
        """Step 1 of 2: re-confirm password before sending OTP."""
        data     = request.get_json(silent=True) or {}
        password = str(data.get("password", ""))
        ip       = _ip()

        if not bcrypt.checkpw(password.encode(), current_user.password_hash.encode()):
            current_user.failed_history_verify_count += 1
            db.session.commit()
            count = current_user.failed_history_verify_count

            if 3 <= count < 5:
                lock = datetime.now(timezone.utc) + timedelta(minutes=30)
                current_user.history_locked_until = lock.isoformat()
                db.session.commit()
                return jsonify({"error": "History locked for 30 minutes."}), 403

            if count >= 5:
                _ban(current_user.id, ip,
                     "5 failed history verifications", "HISTORY_BRUTE_FORCE",
                     f"Count: {count}")
                return jsonify({"error": "Account suspended."}), 403

            return jsonify({"error": "Incorrect password."}), 401

        current_user.failed_history_verify_count = 0
        db.session.commit()
        return jsonify({"message": "Password verified. Request OTP."}), 200

    @app.route("/api/history/send-otp", methods=["POST"])
    @login_required
    @limiter.limit("5 per hour")
    def history_send_otp():
        """Step 2 of 2: generate and email a 6-digit OTP."""
        otp = str(uuid.uuid4().int)[:6]
        session["history_otp"]         = otp
        session["history_otp_expires"] = (
            datetime.now(timezone.utc) + timedelta(minutes=5)
        ).isoformat()

        try:
            mail.send(Message(
                subject="WebGuard — Your History Access Code",
                recipients=[current_user.email],
                body=f"Your one-time code: {otp}\n\nExpires in 5 minutes.",
            ))
        except Exception:
            pass  # Log server-side in production; don't expose mail errors

        return jsonify({"message": "OTP sent to your email."}), 200

    @app.route("/api/history/verify-otp", methods=["POST"])
    @login_required
    @limiter.limit("10 per hour")
    def history_verify_otp():
        """Verify the OTP → grant history_verified for 10 minutes."""
        data        = request.get_json(silent=True) or {}
        submitted   = str(data.get("otp", "")).strip()
        stored      = session.get("history_otp")
        expires_str = session.get("history_otp_expires")

        if not stored or not expires_str:
            return jsonify({"error": "No active OTP. Request a new one."}), 400

        if datetime.now(timezone.utc) > datetime.fromisoformat(expires_str):
            session.pop("history_otp", None)
            return jsonify({"error": "OTP expired. Request a new one."}), 400

        if submitted != stored:
            return jsonify({"error": "Invalid OTP."}), 401

        # Grant access
        session["history_verified"]    = True   # Must be bool True — enforced in before_request
        session["history_verified_at"] = datetime.now(timezone.utc).isoformat()
        session.pop("history_otp", None)
        session.pop("history_otp_expires", None)

        return jsonify({"message": "Verified. History access granted for 10 minutes."}), 200

    @app.route("/api/history", methods=["GET"])
    @login_required
    def get_history():
        if not session.get("history_verified"):
            return jsonify({"error": "Identity verification required."}), 403

        scans = (
            ScanHistory.query
            .filter_by(user_id=current_user.id, deleted=False)
            .order_by(ScanHistory.created_at.desc())
            .all()
        )

        results = []
        for s in scans:
            decrypted = json.loads(fernet.decrypt(s.encrypted_result.encode()))
            results.append({
                "id":     s.id,
                "url":    s.target_url,
                "date":   s.created_at.isoformat(),
                "result": decrypted,
            })

        return jsonify({"scans": results}), 200

    @app.route("/api/history/<scan_id>", methods=["DELETE"])
    @login_required
    def delete_history(scan_id):
        if not session.get("history_verified"):
            return jsonify({"error": "Identity verification required."}), 403

        scan = ScanHistory.query.get(scan_id)

        if not scan or scan.deleted:
            return jsonify({"error": "Not found."}), 404

        # CRITICAL: if the scan belongs to a different user → immediate ban
        # This is an IDOR (Insecure Direct Object Reference) attack
        if scan.user_id != current_user.id:
            _ban(current_user.id, _ip(),
                 "IDOR — accessed another user's scan", "IDOR_ATTACK",
                 f"Scan {scan_id} owned by {scan.user_id}, not {current_user.id}")
            return jsonify({"error": "Account suspended."}), 403

        scan.deleted = True   # Soft delete — data kept for audit
        db.session.commit()
        return jsonify({"message": "Scan deleted."}), 200

    # ==========================================================
    #  OWNER ROUTES
    # ==========================================================

    @app.route("/api/owner/verify-2fa", methods=["POST"])
    def owner_verify_2fa():
        """Complete owner login by verifying TOTP code."""
        pre_id = session.get("pre_2fa_user_id")
        if not pre_id:
            return jsonify({"error": "No pending 2FA session."}), 400

        data = request.get_json(silent=True) or {}
        code = str(data.get("code", "")).strip()
        user = User.query.get(pre_id)

        if not user or user.role != "owner":
            return jsonify({"error": "Invalid session."}), 401

        # Check lockout
        if user.two_fa_locked_until:
            lock = datetime.fromisoformat(user.two_fa_locked_until).replace(
                tzinfo=timezone.utc
            )
            if datetime.now(timezone.utc) < lock:
                mins = int((lock - datetime.now(timezone.utc)).total_seconds() / 60)
                return jsonify({"error": f"2FA locked for {mins} more minutes."}), 403

        # valid_window=1 → allows ±30 seconds for clock drift
        totp = pyotp.TOTP(user.totp_secret)
        if not totp.verify(code, valid_window=1):
            user.failed_2fa_count += 1
            db.session.commit()
            if user.failed_2fa_count >= 3:
                lock_until = datetime.now(timezone.utc) + timedelta(hours=1)
                user.two_fa_locked_until = lock_until.isoformat()
                user.failed_2fa_count = 0
                db.session.commit()
                return jsonify({"error": "2FA locked for 1 hour."}), 403
            return jsonify({"error": "Invalid 2FA code."}), 401

        # Success
        user.failed_2fa_count    = 0
        user.two_fa_locked_until = None
        db.session.commit()

        session.pop("pre_2fa_user_id", None)
        login_user(user, remember=False)
        session.permanent = True
        session["owner_2fa_verified"]    = True
        session["owner_2fa_verified_at"] = datetime.now(timezone.utc).isoformat()
        session["owner_session_ip"]      = _ip()

        return jsonify({"message": "2FA verified. Owner session active."}), 200

    @app.route("/api/owner/stats", methods=["GET"])
    @login_required
    @require_owner_2fa
    def owner_stats():
        return jsonify({
            "total_users":        User.query.filter_by(role="user").count(),
            "total_scans":        ScanHistory.query.filter_by(deleted=False).count(),
            "banned_users":       BannedUser.query.count(),
            "banned_ips":         BannedIP.query.count(),
            "security_incidents": SecurityIncident.query.count(),
        }), 200

    @app.route("/api/owner/users", methods=["GET"])
    @login_required
    @require_owner_2fa
    def owner_users():
        users = User.query.all()
        return jsonify({"users": [
            {
                "id":                   u.id,
                "email":                u.email,
                "role":                 u.role,
                "is_banned":            u.is_banned,
                "disclaimer_accepted":  u.disclaimer_accepted,
                "created_at":           u.created_at.isoformat(),
            }
            for u in users
        ]}), 200

    @app.route("/api/owner/bans", methods=["GET"])
    @login_required
    @require_owner_2fa
    def owner_bans():
        return jsonify({
            "banned_users": [
                {"user_id": b.user_id, "reason": b.reason,
                 "banned_at": b.banned_at.isoformat()}
                for b in BannedUser.query.all()
            ],
            "banned_ips": [
                {"ip": b.ip_address, "reason": b.reason,
                 "banned_at": b.banned_at.isoformat()}
                for b in BannedIP.query.all()
            ],
        }), 200

    @app.route("/api/owner/incidents", methods=["GET"])
    @login_required
    @require_owner_2fa
    def owner_incidents():
        rows = (
            SecurityIncident.query
            .order_by(SecurityIncident.occurred_at.desc())
            .limit(100)
            .all()
        )
        return jsonify({"incidents": [
            {
                "id":          i.id,
                "user_id":     i.user_id,
                "ip":          i.ip_address,
                "type":        i.incident_type,
                "details":     i.details,
                "occurred_at": i.occurred_at.isoformat(),
            }
            for i in rows
        ]}), 200

    @app.route("/api/owner/lift-ban", methods=["POST"])
    @login_required
    @require_owner_2fa
    def owner_lift_ban():
        """
        Lift a ban. Requires 2FA to have been verified within the last 5 minutes.
        This is a sensitive action — the short window forces re-verification.
        """
        ts = session.get("owner_2fa_verified_at")
        if not ts:
            return jsonify({"error": "2FA required."}), 403
        if datetime.now(timezone.utc) - datetime.fromisoformat(ts) > timedelta(minutes=5):
            return jsonify({"error": "Re-verify 2FA to perform this action."}), 403

        data       = request.get_json(silent=True) or {}
        user_id    = data.get("user_id")
        ip_address = data.get("ip_address")

        if user_id:
            u = User.query.get(user_id)
            if u:
                u.is_banned = False
                BannedUser.query.filter_by(user_id=user_id).delete()
                db.session.commit()

        if ip_address:
            BannedIP.query.filter_by(ip_address=ip_address).delete()
            db.session.commit()

        return jsonify({"message": "Ban lifted."}), 200

    # ==========================================================
    #  Create DB tables on first run
    # ==========================================================
    with app.app_context():
        db.create_all()

    return app


# =============================================================
#  Entry Point
# =============================================================
if __name__ == "__main__":
    application = create_app()
    # debug=False is CRITICAL — debug=True exposes an interactive
    # Python shell in the browser — a catastrophic vulnerability
    application.run(debug=False, host="127.0.0.1", port=5000)
