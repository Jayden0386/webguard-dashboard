# security.py
# Shared security helpers: ban system, threat detection, Fernet encryption,
# SSRF protection, SQL injection pattern detection, session validation.
# Import these into app.py and routes — do NOT duplicate logic.

import re
import json
import ipaddress
from datetime import datetime, timedelta
from flask import request, session, jsonify
from cryptography.fernet import Fernet
import os

# ---------------------------------------------------------------------------
# Fernet encryption — scan results stored encrypted in DB
# ---------------------------------------------------------------------------

def get_fernet():
    """Return a Fernet instance using ENCRYPTION_KEY from .env."""
    key = os.environ.get("ENCRYPTION_KEY")
    if not key:
        raise RuntimeError("ENCRYPTION_KEY not set in .env")
    return Fernet(key.encode())


def encrypt_data(data: dict) -> str:
    """Serialize dict to JSON and encrypt with Fernet. Returns base64 string."""
    f = get_fernet()
    json_bytes = json.dumps(data).encode("utf-8")
    return f.encrypt(json_bytes).decode("utf-8")


def decrypt_data(token: str) -> dict:
    """Decrypt a Fernet token and return the original dict."""
    f = get_fernet()
    json_bytes = f.decrypt(token.encode("utf-8"))
    return json.loads(json_bytes.decode("utf-8"))


# ---------------------------------------------------------------------------
# SSRF protection — reject internal/private IPs as scan targets
# ---------------------------------------------------------------------------

# These patterns must NEVER be scan targets
BLOCKED_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),     # loopback
    ipaddress.ip_network("10.0.0.0/8"),       # private class A
    ipaddress.ip_network("172.16.0.0/12"),    # private class B
    ipaddress.ip_network("192.168.0.0/16"),   # private class C
    ipaddress.ip_network("169.254.0.0/16"),   # link-local
    ipaddress.ip_network("::1/128"),          # IPv6 loopback
    ipaddress.ip_network("fc00::/7"),         # IPv6 private
]


def is_ssrf_target(hostname: str) -> bool:
    """
    Returns True if the hostname resolves to a private/internal IP.
    Call this before EVERY scan request.
    If True → reject the scan and ban the user.
    """
    import socket
    try:
        # Resolve hostname to IP
        ip_str = socket.gethostbyname(hostname)
        ip = ipaddress.ip_address(ip_str)
        for network in BLOCKED_NETWORKS:
            if ip in network:
                return True
        return False
    except (socket.gaierror, ValueError):
        # Can't resolve = block it to be safe
        return True


# ---------------------------------------------------------------------------
# SQL injection detection — check all incoming string values
# ---------------------------------------------------------------------------

# Patterns that strongly indicate SQL injection attempts
SQL_INJECTION_PATTERNS = [
    r"'.*--",                        # comment after quote: ' --
    r"union\s+select",               # UNION SELECT
    r"drop\s+table",                 # DROP TABLE
    r"insert\s+into",                # INSERT INTO
    r"delete\s+from",                # DELETE FROM
    r";\s*drop",                     # ; DROP
    r"1\s*=\s*1",                    # 1=1
    r"or\s+1\s*=\s*1",              # OR 1=1
    r"'\s+or\s+'",                   # ' or '
    r"exec\s*\(",                    # exec(
    r"xp_cmdshell",                  # MSSQL shell
    r"<script",                      # basic XSS probe
    r"javascript:",                  # JS injection
]

COMPILED_SQL_PATTERNS = [re.compile(p, re.IGNORECASE) for p in SQL_INJECTION_PATTERNS]


def contains_sql_injection(value: str) -> bool:
    """Return True if the string matches any known SQL injection pattern."""
    for pattern in COMPILED_SQL_PATTERNS:
        if pattern.search(value):
            return True
    return False


def scan_request_for_sql_injection() -> bool:
    """
    Check all incoming request values (JSON body, args, form) for injection.
    Returns True if any field looks like an attack.
    """
    # Check JSON body
    if request.is_json:
        try:
            data = request.get_json(silent=True) or {}
            for v in _flatten_values(data):
                if isinstance(v, str) and contains_sql_injection(v):
                    return True
        except Exception:
            pass

    # Check query string args
    for v in request.args.values():
        if contains_sql_injection(v):
            return True

    # Check form data
    for v in request.form.values():
        if contains_sql_injection(v):
            return True

    return False


def _flatten_values(data, depth=0):
    """Recursively yield all string values from a dict/list (max 3 levels deep)."""
    if depth > 3:
        return
    if isinstance(data, dict):
        for v in data.values():
            yield from _flatten_values(v, depth + 1)
    elif isinstance(data, list):
        for item in data:
            yield from _flatten_values(item, depth + 1)
    else:
        yield data


# ---------------------------------------------------------------------------
# Sensitive path detection — detect probing for /.env, /.git, etc.
# ---------------------------------------------------------------------------

SENSITIVE_PATHS = [
    r"/\.env",
    r"/\.git",
    r"/config",
    r"/database",
    r"/backup",
    r"/wp-config",
    r"/phpinfo",
    r"\.sql$",
    r"/admin/?\?",
]

COMPILED_PATH_PATTERNS = [re.compile(p, re.IGNORECASE) for p in SENSITIVE_PATHS]


def is_probing_sensitive_path(path: str) -> bool:
    """Return True if the request path looks like an attacker probing for sensitive files."""
    for pattern in COMPILED_PATH_PATTERNS:
        if pattern.search(path):
            return True
    return False


# ---------------------------------------------------------------------------
# History session flag validation — detect session tampering
# ---------------------------------------------------------------------------

def is_history_session_valid() -> bool:
    """
    Check that history_verified in session:
    1. Was set by the server (not forged — we verify the timestamp)
    2. Is not expired (10-minute window)
    Returns False if invalid or expired.
    """
    if not session.get("history_verified"):
        return False

    verified_at = session.get("history_verified_at")
    if not verified_at:
        # Flag present but no timestamp — possible tampering
        return False

    try:
        verified_dt = datetime.fromisoformat(verified_at)
        if datetime.utcnow() - verified_dt > timedelta(minutes=10):
            # Expired — clear the flag
            session.pop("history_verified", None)
            session.pop("history_verified_at", None)
            return False
    except (ValueError, TypeError):
        return False

    return True


def set_history_verified():
    """Called after successful history re-authentication. Sets the 10-min flag."""
    session["history_verified"] = True
    session["history_verified_at"] = datetime.utcnow().isoformat()


# ---------------------------------------------------------------------------
# Ban helpers — used in app.py's ban_user() function
# ---------------------------------------------------------------------------

def get_client_ip() -> str:
    """
    Get the real client IP. Checks X-Forwarded-For for proxied setups,
    but only trusts it if running behind a known proxy.
    For simplicity in dev: just return remote_addr.
    """
    # In production behind a reverse proxy, enable X-Forwarded-For parsing
    # via ProxyFix middleware. Never trust it raw in production.
    return request.remote_addr or "unknown"
