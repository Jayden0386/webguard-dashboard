# ============================================================
# routes/auth.py — Authentication Routes
# ============================================================
# Handles: register, login, logout, disclaimer acceptance
#
# SECURITY NOTES:
# - Passwords hashed with bcrypt (never stored plain)
# - Failed logins tracked → auto-ban after 10 failures
# - Session regenerated on login/logout
# - Timing-safe password comparison (bcrypt handles this)
# - Same error message for "user not found" vs "wrong password"
#   (prevents username enumeration attacks)
# ============================================================

import re
from datetime import datetime

from flask import Blueprint, request, jsonify, session
from flask_login import login_user, logout_user, login_required, current_user
import bcrypt

from models import db, User, SecurityIncident
from app import _log_incident, _ban_and_log, get_remote_address

auth_bp = Blueprint("auth", __name__)


# ============================================================
# INPUT VALIDATION HELPERS
# ============================================================

def validate_email(email: str) -> bool:
    """Basic email format validation."""
    pattern = r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def validate_username(username: str) -> bool:
    """
    Username rules: 3-30 chars, letters/numbers/underscores/hyphens only.
    No spaces or special characters — prevents injection via username field.
    """
    pattern = r'^[a-zA-Z0-9_\-]{3,30}$'
    return bool(re.match(pattern, username))


def validate_password_strength(password: str) -> tuple[bool, str]:
    """
    Password must be:
    - At least 8 characters
    - At least one uppercase letter
    - At least one lowercase letter
    - At least one digit
    - At least one special character
    """
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    if not re.search(r'\d', password):
        return False, "Password must contain at least one number"
    if not re.search(r'[!@#$%^&*(),.?":{}|<>_\-]', password):
        return False, "Password must contain at least one special character"
    return True, "OK"


# ============================================================
# POST /api/auth/register
# ============================================================
@auth_bp.route("/register", methods=["POST"])
def register():
    """
    Register a new user account.

    Expected JSON body:
    {
        "username": "johndoe",
        "email": "john@example.com",
        "password": "SecureP@ss1"
    }
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid request — expected JSON body"}), 400

    # Extract and strip whitespace from inputs
    username = str(data.get("username", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))

    # ---- Validate all inputs ----
    if not username or not email or not password:
        return jsonify({"error": "Username, email, and password are required"}), 400

    if not validate_username(username):
        return jsonify({"error": "Username must be 3-30 characters (letters, numbers, _ and - only)"}), 400

    if not validate_email(email):
        return jsonify({"error": "Invalid email address"}), 400

    strong, msg = validate_password_strength(password)
    if not strong:
        return jsonify({"error": msg}), 400

    # ---- Check for existing accounts ----
    # Use the same error message for both cases to prevent username/email enumeration
    existing_user = User.query.filter(
        (User.username == username) | (User.email == email)
    ).first()

    if existing_user:
        return jsonify({"error": "An account with that username or email already exists"}), 409

    # ---- Hash the password with bcrypt ----
    # bcrypt.gensalt(12) — work factor 12. Higher = slower to brute-force.
    # This takes ~0.3 seconds, which is intentional (makes brute-force impractical)
    password_hash = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(12))

    # ---- Create the user ----
    new_user = User(
        username=username,
        email=email,
        password_hash=password_hash.decode("utf-8"),  # Store as string in DB
        role="user",
        disclaimer_accepted=False
    )

    db.session.add(new_user)
    db.session.commit()

    return jsonify({
        "message": "Account created successfully",
        "user": {
            "id": new_user.id,
            "username": new_user.username,
            "email": new_user.email,
            "disclaimer_accepted": new_user.disclaimer_accepted
        }
    }), 201


# ============================================================
# POST /api/auth/login
# ============================================================
@auth_bp.route("/login", methods=["POST"])
def login():
    """
    Log in a user. For owner accounts, this only does password
    verification — 2FA is a separate step.

    Expected JSON body:
    {
        "username": "johndoe",
        "password": "SecureP@ss1"
    }
    """
    # Don't let already-logged-in users hit this endpoint
    if current_user.is_authenticated:
        return jsonify({"error": "Already logged in"}), 400

    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid request"}), 400

    username = str(data.get("username", "")).strip()
    password = str(data.get("password", ""))

    if not username or not password:
        return jsonify({"error": "Username and password are required"}), 400

    # ---- Look up the user ----
    user = User.query.filter_by(username=username).first()

    # ---- SECURITY: Generic error message ----
    # Whether user doesn't exist OR password is wrong, return the same message.
    # This prevents attackers from figuring out which usernames are registered.
    GENERIC_ERROR = "Invalid username or password"

    if not user:
        # Still do a dummy bcrypt check to prevent timing attacks
        # (if we return immediately when user not found, attackers can
        # measure the response time and know the username doesn't exist)
        bcrypt.checkpw(b"dummy", bcrypt.hashpw(b"dummy", bcrypt.gensalt(12)))
        _log_incident(
            incident_type="failed_login_unknown_user",
            severity="low",
            details=f"Login attempt for non-existent username: {username[:50]}",
            action_taken="logged_only"
        )
        return jsonify({"error": GENERIC_ERROR}), 401

    # ---- Check if account is banned ----
    if user.is_banned:
        return jsonify({"error": "Account suspended."}), 403

    # ---- Verify the password ----
    password_correct = bcrypt.checkpw(
        password.encode("utf-8"),
        user.password_hash.encode("utf-8")
    )

    if not password_correct:
        # Track failed attempts
        user.failed_login_attempts += 1
        user.last_failed_login = datetime.utcnow()
        db.session.commit()

        _log_incident(
            incident_type="failed_login",
            severity="medium",
            details=f"Failed login for user: {username}",
            action_taken="logged_only",
            user=user
        )

        # Auto-ban after 10 failed attempts
        if user.failed_login_attempts >= 10:
            _ban_and_log(
                user=user,
                ip=get_remote_address(),
                reason="Exceeded maximum failed login attempts (10)",
                incident_type="excessive_failed_logins",
                severity="high",
                details=f"10+ failed logins for user {username}",
                action="account_banned"
            )
            return jsonify({"error": "Account suspended."}), 403

        return jsonify({"error": GENERIC_ERROR}), 401

    # ---- Password correct — reset fail counter ----
    user.failed_login_attempts = 0
    user.last_login = datetime.utcnow()
    db.session.commit()

    # ---- Owner: require 2FA ----
    if user.role == "owner":
        # Don't fully log in yet — store pending state for 2FA
        session.clear()
        session["pending_owner_id"] = user.id
        session["pending_owner_at"] = datetime.utcnow().isoformat()

        return jsonify({
            "message": "Password verified. 2FA required.",
            "requires_2fa": True
        }), 200

    # ---- Regular user: log in ----
    login_user(user, remember=False)

    # Regenerate session ID after login (prevents session fixation attacks)
    # Flask-Login handles this internally when remember=False

    return jsonify({
        "message": "Logged in successfully",
        "user": {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "role": user.role,
            "disclaimer_accepted": user.disclaimer_accepted
        }
    }), 200


# ============================================================
# POST /api/auth/logout
# ============================================================
@auth_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    """
    Log out the current user.
    Clears all session data including history_verified flags.
    """
    logout_user()
    session.clear()  # Remove ALL session data, not just Flask-Login's

    return jsonify({"message": "Logged out successfully"}), 200


# ============================================================
# POST /api/auth/disclaimer
# ============================================================
@auth_bp.route("/disclaimer", methods=["POST"])
@login_required
def accept_disclaimer():
    """
    Mark that the user has accepted the ethical use disclaimer.
    This is required before they can run any scans.

    The disclaimer must state:
    - Only scan sites you OWN or have WRITTEN PERMISSION to test
    - Unauthorized scanning is ILLEGAL
    - Misuse will result in immediate account suspension

    Expected JSON body:
    {
        "accepted": true
    }
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid request"}), 400

    accepted = data.get("accepted")

    if accepted is not True:
        return jsonify({"error": "You must explicitly accept the disclaimer to continue"}), 400

    user = User.query.get(current_user.id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    user.disclaimer_accepted = True
    user.disclaimer_accepted_at = datetime.utcnow()
    db.session.commit()

    return jsonify({
        "message": "Disclaimer accepted. You may now use the scanner.",
        "disclaimer_accepted": True,
        "accepted_at": user.disclaimer_accepted_at.isoformat()
    }), 200


# ============================================================
# GET /api/auth/me
# ============================================================
@auth_bp.route("/me", methods=["GET"])
@login_required
def get_current_user():
    """
    Returns the current logged-in user's info.
    Used by the frontend to check auth state on page load.
    """
    return jsonify({
        "user": {
            "id": current_user.id,
            "username": current_user.username,
            "email": current_user.email,
            "role": current_user.role,
            "disclaimer_accepted": current_user.disclaimer_accepted
        }
    }), 200
