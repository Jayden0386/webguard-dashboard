# ============================================================
# routes/owner.py — Owner/Admin Routes
# ============================================================
# Owner has special privileges: view all users, view bans,
# view security incidents, lift bans.
#
# SECURITY RULES FOR OWNER:
# - One owner account only (created via create_owner.py)
# - Every login requires: password + TOTP 2FA code
# - Owner session expires after 15 minutes
# - Session is bound to the IP at login time
# - Sensitive actions (lift ban) require 2FA re-verification
# - Wrong 2FA code 3 times → 1-hour lockout
# ============================================================

import os
import pyotp
from datetime import datetime, timedelta

from flask import Blueprint, request, jsonify, session
from flask_login import login_required, current_user

from models import db, User, ScanHistory, BannedUser, BannedIP, SecurityIncident
from app import _log_incident, _ban_and_log, get_remote_address

owner_bp = Blueprint("owner", __name__)


# ============================================================
# OWNER AUTH DECORATORS
# ============================================================

def owner_required(f):
    """
    Decorator: ensures the user is the owner AND has completed 2FA.
    Also checks that the session hasn't expired (15 minutes).
    Also verifies the IP hasn't changed (session binding).

    Use this on ALL owner routes.
    """
    from functools import wraps

    @wraps(f)
    def decorated(*args, **kwargs):
        # ---- Basic auth check ----
        if not current_user.is_authenticated:
            return jsonify({"error": "Authentication required"}), 401

        if current_user.role != "owner":
            _log_incident(
                incident_type="unauthorized_owner_access",
                severity="high",
                details=f"Non-owner user {current_user.username} attempted to access owner route",
                action_taken="request_blocked",
                user=current_user
            )
            return jsonify({"error": "Not authorized"}), 403

        # ---- 2FA check ----
        if not session.get("owner_2fa_verified"):
            return jsonify({
                "error": "Owner 2FA verification required",
                "requires_2fa": True
            }), 403

        # ---- Session expiry (15 minutes) ----
        verified_at_str = session.get("owner_2fa_verified_at")
        if verified_at_str:
            verified_at = datetime.fromisoformat(verified_at_str)
            if datetime.utcnow() - verified_at > timedelta(minutes=15):
                session.pop("owner_2fa_verified", None)
                session.pop("owner_2fa_verified_at", None)
                return jsonify({
                    "error": "Owner session expired. Please re-verify 2FA.",
                    "requires_2fa": True
                }), 403

        # ---- IP binding check ----
        bound_ip = session.get("owner_session_ip")
        current_ip = get_remote_address()
        if bound_ip and bound_ip != current_ip:
            _ban_and_log(
                user=current_user,
                ip=current_ip,
                reason="Owner session used from different IP — possible session hijacking",
                incident_type="owner_session_ip_mismatch",
                severity="critical",
                details=f"Session created on {bound_ip}, now used from {current_ip}",
                action="account_banned"
            )
            session.clear()
            return jsonify({"error": "Account suspended."}), 403

        return f(*args, **kwargs)
    return decorated


def owner_2fa_required_for_action(f):
    """
    Additional decorator for sensitive owner actions.
    Requires a fresh 2FA verification (within last 5 minutes).
    """
    from functools import wraps

    @wraps(f)
    def decorated(*args, **kwargs):
        # Check that 2FA was done VERY recently for sensitive actions
        verified_at_str = session.get("owner_2fa_verified_at")
        if not verified_at_str:
            return jsonify({
                "error": "2FA re-verification required for this action",
                "requires_2fa_reauth": True
            }), 403

        verified_at = datetime.fromisoformat(verified_at_str)
        if datetime.utcnow() - verified_at > timedelta(minutes=5):
            return jsonify({
                "error": "Please re-verify your 2FA code to perform this action",
                "requires_2fa_reauth": True
            }), 403

        return f(*args, **kwargs)
    return decorated


# ============================================================
# POST /api/owner/verify-2fa
# ============================================================
@owner_bp.route("/verify-2fa", methods=["POST"])
@login_required
def verify_2fa():
    """
    Verify the owner's TOTP code.

    This is called AFTER password login (which sets pending_owner_id in session).
    On success: logs the owner in fully and sets owner_2fa_verified in session.

    TOTP (Time-based One-Time Password):
    - Uses pyotp library
    - 6-digit code
    - Changes every 30 seconds
    - Generated by authenticator app (Google Authenticator, Authy, etc.)
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid request"}), 400

    totp_code = str(data.get("code", "")).strip()

    if not totp_code or not totp_code.isdigit() or len(totp_code) != 6:
        return jsonify({"error": "TOTP code must be a 6-digit number"}), 400

    # ---- Find the owner account ----
    # Could be from pending login OR from already-logged-in owner re-verifying
    if current_user.is_authenticated and current_user.role == "owner":
        owner = User.query.get(current_user.id)
    elif session.get("pending_owner_id"):
        owner = User.query.get(session["pending_owner_id"])
    else:
        return jsonify({"error": "No pending owner session found"}), 400

    if not owner or owner.role != "owner":
        return jsonify({"error": "Not authorized"}), 403

    # ---- Check 2FA lockout ----
    lockout_key = f"owner_2fa_failures"
    failures = session.get(lockout_key, 0)
    lockout_until_str = session.get("owner_2fa_lockout_until")

    if lockout_until_str:
        lockout_until = datetime.fromisoformat(lockout_until_str)
        if datetime.utcnow() < lockout_until:
            remaining = int((lockout_until - datetime.utcnow()).total_seconds() / 60)
            return jsonify({
                "error": f"2FA locked for {remaining} more minutes due to failed attempts."
            }), 429

    # ---- Verify the TOTP code ----
    if not owner.totp_secret:
        return jsonify({"error": "2FA not configured for this account. Run create_owner.py"}), 500

    totp = pyotp.TOTP(owner.totp_secret)

    # valid_window=1 allows 1 time step (30 sec) before/after for clock skew
    if not totp.verify(totp_code, valid_window=1):
        failures += 1
        session[lockout_key] = failures

        _log_incident(
            incident_type="failed_owner_2fa",
            severity="high",
            details=f"Failed 2FA attempt #{failures} for owner account",
            action_taken="logged_only",
            user=owner
        )

        # 3 failures → 1-hour lockout
        if failures >= 3:
            session["owner_2fa_lockout_until"] = (
                datetime.utcnow() + timedelta(hours=1)
            ).isoformat()
            return jsonify({
                "error": "Too many failed attempts. 2FA locked for 1 hour."
            }), 429

        return jsonify({"error": f"Invalid 2FA code. {3 - failures} attempts remaining."}), 401

    # ---- 2FA correct — complete owner login ----
    session.pop(lockout_key, None)
    session.pop("owner_2fa_lockout_until", None)
    session.pop("pending_owner_id", None)
    session.pop("pending_owner_at", None)

    # Log the owner in via Flask-Login (if coming from password step)
    if not current_user.is_authenticated:
        from flask_login import login_user
        login_user(owner, remember=False)

    # Set owner session flags
    session["owner_2fa_verified"] = True
    session["owner_2fa_verified_at"] = datetime.utcnow().isoformat()
    session["owner_session_ip"] = get_remote_address()  # Bind session to IP

    return jsonify({
        "message": "2FA verified. Owner access granted.",
        "owner": {
            "id": owner.id,
            "username": owner.username,
            "email": owner.email
        }
    }), 200


# ============================================================
# GET /api/owner/stats
# ============================================================
@owner_bp.route("/stats", methods=["GET"])
@login_required
@owner_required
def get_stats():
    """
    System overview statistics for the owner dashboard.
    """
    total_users = User.query.filter_by(role="user").count()
    active_users = User.query.filter_by(role="user", is_banned=False, is_active=True).count()
    banned_count = User.query.filter_by(is_banned=True).count()
    total_scans = ScanHistory.query.count()
    completed_scans = ScanHistory.query.filter_by(status="complete").count()
    total_incidents = SecurityIncident.query.count()
    critical_incidents = SecurityIncident.query.filter_by(severity="critical").count()

    # Recent activity (last 7 days)
    week_ago = datetime.utcnow() - timedelta(days=7)
    recent_scans = ScanHistory.query.filter(ScanHistory.created_at >= week_ago).count()
    recent_incidents = SecurityIncident.query.filter(
        SecurityIncident.occurred_at >= week_ago
    ).count()

    return jsonify({
        "users": {
            "total": total_users,
            "active": active_users,
            "banned": banned_count
        },
        "scans": {
            "total": total_scans,
            "completed": completed_scans,
            "last_7_days": recent_scans
        },
        "security": {
            "total_incidents": total_incidents,
            "critical_incidents": critical_incidents,
            "last_7_days": recent_incidents
        }
    }), 200


# ============================================================
# GET /api/owner/users
# ============================================================
@owner_bp.route("/users", methods=["GET"])
@login_required
@owner_required
def get_users():
    """
    List all user accounts. Owner use only.
    Excludes password hashes and other sensitive internal fields.
    """
    users = User.query.filter(User.role != "owner").order_by(User.created_at.desc()).all()

    users_list = []
    for user in users:
        scan_count = ScanHistory.query.filter_by(user_id=user.id).count()
        users_list.append({
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "role": user.role,
            "is_banned": user.is_banned,
            "is_active": user.is_active,
            "disclaimer_accepted": user.disclaimer_accepted,
            "scan_count": scan_count,
            "created_at": user.created_at.isoformat(),
            "last_login": user.last_login.isoformat() if user.last_login else None,
            "failed_login_attempts": user.failed_login_attempts
        })

    return jsonify({
        "users": users_list,
        "total": len(users_list)
    }), 200


# ============================================================
# GET /api/owner/bans
# ============================================================
@owner_bp.route("/bans", methods=["GET"])
@login_required
@owner_required
def get_bans():
    """
    List all banned accounts and IPs.
    """
    banned_users = BannedUser.query.order_by(BannedUser.banned_at.desc()).all()
    banned_ips = BannedIP.query.order_by(BannedIP.banned_at.desc()).all()

    return jsonify({
        "banned_users": [
            {
                "id": b.id,
                "user_id": b.user_id,
                "username": b.username,
                "email": b.email,
                "reason": b.reason,
                "trigger_event": b.trigger_event,
                "banned_at": b.banned_at.isoformat(),
                "banned_by": b.banned_by
            }
            for b in banned_users
        ],
        "banned_ips": [
            {
                "id": b.id,
                "ip_address": b.ip_address,
                "reason": b.reason,
                "associated_username": b.associated_username,
                "banned_at": b.banned_at.isoformat()
            }
            for b in banned_ips
        ],
        "totals": {
            "banned_users": len(banned_users),
            "banned_ips": len(banned_ips)
        }
    }), 200


# ============================================================
# GET /api/owner/incidents
# ============================================================
@owner_bp.route("/incidents", methods=["GET"])
@login_required
@owner_required
def get_incidents():
    """
    Full security incident log. Paginated — 50 per page.
    """
    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 50, type=int), 100)

    incidents_query = SecurityIncident.query.order_by(
        SecurityIncident.occurred_at.desc()
    ).paginate(page=page, per_page=per_page, error_out=False)

    return jsonify({
        "incidents": [
            {
                "id": inc.id,
                "user_id": inc.user_id,
                "username": inc.username,
                "ip_address": inc.ip_address,
                "incident_type": inc.incident_type,
                "severity": inc.severity,
                "details": inc.details,
                "action_taken": inc.action_taken,
                "request_path": inc.request_path,
                "occurred_at": inc.occurred_at.isoformat()
            }
            for inc in incidents_query.items
        ],
        "pagination": {
            "page": page,
            "per_page": per_page,
            "total": incidents_query.total,
            "pages": incidents_query.pages
        }
    }), 200


# ============================================================
# POST /api/owner/lift-ban
# ============================================================
@owner_bp.route("/lift-ban", methods=["POST"])
@login_required
@owner_required
@owner_2fa_required_for_action
def lift_ban():
    """
    Lift a ban on a user account and optionally their IP.
    Requires fresh 2FA verification (within 5 minutes).

    Expected JSON body:
    {
        "user_id": "uuid-of-banned-user",
        "lift_ip_ban": true
    }
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid request"}), 400

    user_id = str(data.get("user_id", "")).strip()
    lift_ip = data.get("lift_ip_ban", False)

    if not user_id:
        return jsonify({"error": "user_id is required"}), 400

    # Find the user
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    if not user.is_banned:
        return jsonify({"error": "User is not banned"}), 400

    # Lift the account ban
    user.is_banned = False
    user.is_active = True
    user.banned_at = None
    user.ban_reason = None
    user.failed_login_attempts = 0
    user.failed_history_verifications = 0
    user.history_lockout_until = None

    # Log the ban lift
    _log_incident(
        incident_type="ban_lifted",
        severity="low",
        details=f"Owner lifted ban for user {user.username} (ID: {user_id})",
        action_taken="ban_lifted",
        user=current_user
    )

    # Optionally lift IP ban
    if lift_ip:
        banned_ip_record = BannedIP.query.filter_by(
            associated_user_id=user_id
        ).first()
        if banned_ip_record:
            db.session.delete(banned_ip_record)

    db.session.commit()

    return jsonify({
        "message": f"Ban lifted for user {user.username}",
        "ip_ban_lifted": lift_ip
    }), 200
