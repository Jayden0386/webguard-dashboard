# ============================================================
# routes/scan.py — Vulnerability Scan Endpoint
# ============================================================
# POST /api/scan
#
# SECURITY CHECKS BEFORE SCANNING:
# 1. User must be logged in
# 2. User must have accepted the ethical use disclaimer
# 3. Target URL must NOT be a local/internal IP (SSRF protection)
# 4. Rate limited: 5 scans per hour per user
#
# SSRF (Server-Side Request Forgery) Protection:
# If we allowed scanning localhost or 192.168.x.x, an attacker
# could use our scanner to probe our internal network. We MUST
# block all private/internal IP ranges.
# ============================================================

import json
import re
import socket
from datetime import datetime
from urllib.parse import urlparse

from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user

from models import db, ScanHistory, User
from scanner.checks import run_surface_scan, fetch_page
from scanner.deep_checks import run_deep_scan
from app import _log_incident, _ban_and_log, get_cipher_instance, get_remote_address

scan_bp = Blueprint("scan", __name__)


# ============================================================
# SSRF PROTECTION — Block Private/Internal IPs
# ============================================================

# These are all the IPv4 private/reserved ranges we must NEVER scan
BLOCKED_IP_PATTERNS = [
    re.compile(r'^127\.'),              # Loopback (localhost)
    re.compile(r'^10\.'),               # Class A private network
    re.compile(r'^192\.168\.'),         # Class C private network
    re.compile(r'^172\.(1[6-9]|2\d|3[01])\.'),  # Class B private network
    re.compile(r'^169\.254\.'),         # Link-local
    re.compile(r'^0\.'),               # "This" network
    re.compile(r'^255\.'),             # Broadcast
    re.compile(r'^::1$'),              # IPv6 loopback
    re.compile(r'^fc00:'),             # IPv6 private
    re.compile(r'^fe80:'),             # IPv6 link-local
    re.compile(r'^fd'),                # IPv6 unique local
]

BLOCKED_HOSTNAMES = [
    "localhost", "local", "internal", "intranet",
    "metadata.google.internal",        # GCP metadata service
    "169.254.169.254",                 # AWS/GCP/Azure metadata service
]


def is_ssrf_target(url: str) -> tuple[bool, str]:
    """
    Check if a URL would cause an SSRF attack.
    Returns (True, reason) if the URL is blocked.
    Returns (False, "") if the URL is safe to scan.

    How SSRF works:
    Attacker sends: POST /api/scan {"url": "http://192.168.1.1/admin"}
    If we naively fetch that, we're sending a request from OUR server
    to an internal resource the attacker can't access directly.
    """
    try:
        parsed = urlparse(url)
        hostname = parsed.hostname or ""

        # ---- Block by hostname ----
        if hostname.lower() in BLOCKED_HOSTNAMES:
            return True, f"Blocked hostname: {hostname}"

        # ---- Block obvious private IP strings ----
        for pattern in BLOCKED_IP_PATTERNS:
            if pattern.match(hostname):
                return True, f"Private IP range: {hostname}"

        # ---- DNS resolution check ----
        # Even if the hostname looks innocent, it might resolve to a private IP
        # Example: "evil.com" could have A record pointing to 192.168.1.1
        try:
            resolved_ips = socket.getaddrinfo(hostname, None)
            for result in resolved_ips:
                resolved_ip = result[4][0]
                for pattern in BLOCKED_IP_PATTERNS:
                    if pattern.match(resolved_ip):
                        return True, f"Hostname resolves to private IP: {resolved_ip}"
        except socket.gaierror:
            # Can't resolve — might just be offline, not necessarily malicious
            # We let it through and the scan will fail gracefully
            pass

        return False, ""

    except Exception:
        return True, "Could not validate URL"


def validate_scan_url(url: str) -> tuple[bool, str]:
    """
    Validate that a URL is safe and well-formed for scanning.
    Returns (True, "") if valid, (False, error_message) if not.
    """
    if not url or not isinstance(url, str):
        return False, "URL is required"

    # Strip whitespace
    url = url.strip()

    # Length check
    if len(url) > 500:
        return False, "URL is too long (maximum 500 characters)"

    # Must start with http:// or https://
    if not url.startswith(("http://", "https://")):
        return False, "URL must start with http:// or https://"

    # Parse and validate structure
    try:
        parsed = urlparse(url)
        if not parsed.netloc:
            return False, "Invalid URL — no hostname found"
        if not parsed.hostname:
            return False, "Invalid URL — could not extract hostname"
    except Exception:
        return False, "Invalid URL format"

    # SSRF protection check
    blocked, reason = is_ssrf_target(url)
    if blocked:
        return False, "Scanning internal/private network addresses is not permitted"

    return True, ""


# ============================================================
# POST /api/scan
# ============================================================
@scan_bp.route("/scan", methods=["POST"])
@login_required
def run_scan():
    """
    Main scanning endpoint. Runs both surface and deep scans.

    Expected JSON body:
    {
        "url": "https://example.com"
    }

    Rate limited: 5 scans per hour per user (applied via limiter in app.py).
    """
    # Apply rate limiting via app's limiter
    limiter = current_app.limiter
    with current_app.test_request_context():
        pass  # Rate limiting is applied by the decorator below

    # ---- Check disclaimer acceptance ----
    user = User.query.get(current_user.id)
    if not user.disclaimer_accepted:
        return jsonify({
            "error": "You must accept the ethical use disclaimer before scanning",
            "requires_disclaimer": True
        }), 403

    # ---- Parse and validate request ----
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid request — expected JSON body"}), 400

    target_url = str(data.get("url", "")).strip()

    valid, error_msg = validate_scan_url(target_url)
    if not valid:
        # If they tried to scan an internal IP, that's suspicious — ban them
        if "internal" in error_msg.lower() or "private" in error_msg.lower():
            _ban_and_log(
                user=current_user,
                ip=get_remote_address(),
                reason="Attempted SSRF via scan endpoint",
                incident_type="ssrf_attempt",
                severity="critical",
                details=f"Attempted to scan: {target_url[:200]}",
                action="account_banned"
            )
            return jsonify({"error": "Account suspended."}), 403

        return jsonify({"error": error_msg}), 400

    # ---- Create scan record ----
    scan = ScanHistory(
        user_id=current_user.id,
        target_url=target_url,
        scan_type="full",
        status="running"
    )
    db.session.add(scan)
    db.session.commit()

    # ---- Run the scans ----
    try:
        # Surface scan (fetches the page)
        surface_results = run_surface_scan(target_url)

        # Deep scan reuses the page fetch from surface scan
        # We re-fetch here to keep the modules clean and independent
        from scanner.checks import fetch_page
        from bs4 import BeautifulSoup
        import requests as req

        response, soup, fetch_error = fetch_page(target_url)
        deep_results = run_deep_scan(target_url, soup, response)

        # Combine all findings
        combined = {
            "target": target_url,
            "surface": surface_results,
            "deep": deep_results,
            "scanned_at": datetime.utcnow().isoformat()
        }

        # Determine overall risk level (worst of surface + deep)
        risk_levels = ["info", "low", "medium", "high", "critical"]
        surface_risk = surface_results.get("risk_level", "info")
        deep_risk = deep_results.get("risk_level", "info")
        overall_risk = risk_levels[max(
            risk_levels.index(surface_risk),
            risk_levels.index(deep_risk)
        )]

        # ---- Encrypt the scan results before storing ----
        # This protects scan findings if the database is ever compromised
        cipher = get_cipher_instance()
        encrypted_data = cipher.encrypt(json.dumps(combined).encode("utf-8"))

        # Update scan record
        scan.scan_data = encrypted_data.decode("utf-8")
        scan.status = "complete"
        scan.risk_level = overall_risk
        scan.completed_at = datetime.utcnow()
        db.session.commit()

        return jsonify({
            "message": "Scan complete",
            "scan_id": scan.id,
            "risk_level": overall_risk,
            "results": combined
        }), 200

    except Exception as e:
        # Log the error internally but don't expose it
        _log_incident(
            incident_type="scan_error",
            severity="medium",
            details=str(e)[:200],
            action_taken="scan_failed",
            user=current_user
        )

        scan.status = "failed"
        db.session.commit()

        return jsonify({
            "error": "Scan could not be completed",
            "scan_id": scan.id
        }), 500
