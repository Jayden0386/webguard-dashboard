# ============================================================
# routes/history.py — Scan History Routes
# ============================================================
# Viewing scan history requires a 3-step verification process:
# 1. Re-verify password (POST /api/history/verify-password)
# 2. Receive OTP via email (POST /api/history/send-otp)
# 3. Verify the OTP code (POST /api/history/verify-otp)
# 4. Now access is granted for 10 minutes
#
# WHY so strict?
# Scan results contain sensitive vulnerability data.
# If an attacker steals a session cookie, they still can't
# access history without the OTP sent to the user's email.
#
# AUTO-BAN TRIGGERS:
# - 3 failed verifications → 30-minute lockout
# - 5 total failed verifications → permanent ban
# - Accessing another user's scan → immediate ban
# ============================================================

import json
import random
import string
from datetime import datetime, timedelta

from flask import Blueprint, request, jsonify, session
from flask_login import login_required, current_user
from flask_mail import Message
import bcrypt

from models import db, User, ScanHistory, OTPVerification
from app import _log_incident, _ban_and_log, get_cipher_instance, get_remote_address

history_bp = Blueprint("history", __name__)


# ============================================================
# HELPER: Check history_verified session flag
# ============================================================
def require_history_verified(f):
    """
    Decorator that checks the history_verified session flag.
    The flag expires after 10 minutes (enforced in app.py's before_request).
    """
    from functools import wraps

    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("history_verified"):
            return jsonify({
                "error": "History access requires verification",
                "requires_verification": True
            }), 403
        return f(*args, **kwargs)
    return decorated


# ============================================================
# STEP 1: POST /api/history/verify-password
# ============================================================
@history_bp.route("/verify-password", methods=["POST"])
@login_required
def verify_password():
    """
    Step 1 of history verification.
    User re-enters their password to prove it's really them.

    This prevents an attacker who stole a session cookie from
    immediately accessing all scan history.
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid request"}), 400

    password = str(data.get("password", ""))
    if not password:
        return jsonify({"error": "Password is required"}), 400

    user = User.query.get(current_user.id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    # ---- Check for lockout ----
    if user.history_lockout_until and datetime.utcnow() < user.history_lockout_until:
        remaining = int((user.history_lockout_until - datetime.utcnow()).total_seconds() / 60)
        return jsonify({
            "error": f"Account temporarily locked. Try again in {remaining} minutes."
        }), 429

    # ---- Verify the password ----
    password_correct = bcrypt.checkpw(
        password.encode("utf-8"),
        user.password_hash.encode("utf-8")
    )

    if not password_correct:
        user.failed_history_verifications += 1
        db.session.commit()

        _log_incident(
            incident_type="failed_history_verification",
            severity="medium",
            details=f"Failed password verification for history access",
            action_taken="logged_only",
            user=user
        )

        # 3 failures → 30-minute lockout
        if user.failed_history_verifications >= 3:
            user.history_lockout_until = datetime.utcnow() + timedelta(minutes=30)
            db.session.commit()

        # 5 failures → permanent ban
        if user.failed_history_verifications >= 5:
            _ban_and_log(
                user=current_user,
                ip=get_remote_address(),
                reason="Exceeded maximum failed history verification attempts",
                incident_type="excessive_failed_history_verifications",
                severity="high",
                details=f"5+ failed history verifications for user {user.username}",
                action="account_banned"
            )
            return jsonify({"error": "Account suspended."}), 403

        return jsonify({"error": "Incorrect password"}), 401

    # ---- Password correct ----
    user.failed_history_verifications = 0
    user.history_lockout_until = None
    db.session.commit()

    # Mark password step complete in session
    session["history_pw_verified"] = True
    session["history_pw_verified_at"] = datetime.utcnow().isoformat()

    return jsonify({
        "message": "Password verified. Please check your email for an OTP code.",
        "next_step": "send-otp"
    }), 200


# ============================================================
# STEP 2: POST /api/history/send-otp
# ============================================================
@history_bp.route("/send-otp", methods=["POST"])
@login_required
def send_otp():
    """
    Step 2: Send a one-time password to the user's email.

    Only works if they completed Step 1 (password verification).
    The OTP expires in 10 minutes and can only be used once.
    """
    # Must have completed password step first
    if not session.get("history_pw_verified"):
        return jsonify({"error": "Password verification required first"}), 403

    user = User.query.get(current_user.id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    # ---- Generate a secure 6-digit OTP ----
    # Using secrets module for cryptographically secure randomness
    import secrets
    otp_code = str(secrets.randbelow(900000) + 100000)  # 100000-999999

    # ---- Hash the OTP before storing ----
    # Even OTP codes shouldn't be stored plain
    otp_hash = bcrypt.hashpw(otp_code.encode("utf-8"), bcrypt.gensalt(10))

    # ---- Invalidate any previous unused OTPs ----
    OTPVerification.query.filter_by(
        user_id=user.id,
        used=False
    ).update({"used": True})
    db.session.commit()

    # ---- Store the new OTP (expires in 10 minutes) ----
    otp_record = OTPVerification(
        user_id=user.id,
        code_hash=otp_hash.decode("utf-8"),
        expires_at=datetime.utcnow() + timedelta(minutes=10)
    )
    db.session.add(otp_record)
    db.session.commit()

    # ---- Send the OTP via email ----
    try:
        from flask import current_app
        mail = current_app.mail

        msg = Message(
            subject="WebGuard Scanner — History Access Code",
            recipients=[user.email]
        )
        msg.body = f"""Hello {user.username},

Your one-time access code for WebGuard Scanner history is:

    {otp_code}

This code expires in 10 minutes.
If you did not request this code, someone may be attempting to access your account.

Do not share this code with anyone.

— WebGuard Security System
"""
        mail.send(msg)

    except Exception as e:
        _log_incident(
            incident_type="otp_email_failed",
            severity="medium",
            details=str(e)[:200],
            action_taken="logged_only",
            user=user
        )
        # Don't expose the actual error — just say it failed
        return jsonify({"error": "Failed to send OTP email. Please try again."}), 500

    return jsonify({
        "message": f"OTP sent to {_mask_email(user.email)}",
        "expires_in_minutes": 10
    }), 200


# ============================================================
# STEP 3: POST /api/history/verify-otp
# ============================================================
@history_bp.route("/verify-otp", methods=["POST"])
@login_required
def verify_otp():
    """
    Step 3: Verify the OTP code from email.
    If correct, sets history_verified=True in session (expires in 10 min).
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid request"}), 400

    otp_code = str(data.get("code", "")).strip()

    if not otp_code or not otp_code.isdigit() or len(otp_code) != 6:
        return jsonify({"error": "OTP must be a 6-digit number"}), 400

    user = User.query.get(current_user.id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    # ---- Find the most recent valid OTP ----
    otp_record = OTPVerification.query.filter_by(
        user_id=user.id,
        used=False
    ).order_by(OTPVerification.created_at.desc()).first()

    if not otp_record:
        return jsonify({"error": "No active OTP found. Please request a new one."}), 400

    # ---- Check if OTP has expired ----
    if datetime.utcnow() > otp_record.expires_at:
        otp_record.used = True
        db.session.commit()
        return jsonify({"error": "OTP code has expired. Please request a new one."}), 400

    # ---- Verify the OTP ----
    otp_correct = bcrypt.checkpw(
        otp_code.encode("utf-8"),
        otp_record.code_hash.encode("utf-8")
    )

    if not otp_correct:
        _log_incident(
            incident_type="failed_otp_verification",
            severity="medium",
            details="Wrong OTP code entered for history access",
            action_taken="logged_only",
            user=user
        )
        return jsonify({"error": "Incorrect OTP code"}), 401

    # ---- OTP is correct — mark as used and grant access ----
    otp_record.used = True
    db.session.commit()

    # Set the history_verified flag with timestamp
    # The timestamp is checked in app.py's before_request to expire it after 10 min
    session["history_verified"] = True
    session["history_verified_at"] = datetime.utcnow().isoformat()

    # Clean up the password verification step flag
    session.pop("history_pw_verified", None)
    session.pop("history_pw_verified_at", None)

    return jsonify({
        "message": "Identity verified. History access granted for 10 minutes.",
        "access_granted": True
    }), 200


# ============================================================
# GET /api/history
# ============================================================
@history_bp.route("", methods=["GET"])
@login_required
@require_history_verified
def get_history():
    """
    Get the current user's scan history.
    Requires history_verified session flag (set by OTP verification).

    SECURITY: We ONLY return scans where user_id == current_user.id.
    Any attempt to access another user's scans triggers an immediate ban.
    """
    # Query only this user's scans, excluding soft-deleted ones
    scans = ScanHistory.query.filter_by(
        user_id=current_user.id,
        deleted=False
    ).order_by(ScanHistory.created_at.desc()).all()

    cipher = get_cipher_instance()
    history_list = []

    for scan in scans:
        # ---- Paranoid ownership check ----
        # Even though we queried by user_id, verify again
        if scan.user_id != current_user.id:
            _ban_and_log(
                user=current_user,
                ip=get_remote_address(),
                reason="Attempted to access another user's scan history",
                incident_type="unauthorized_history_access",
                severity="critical",
                details=f"User {current_user.id} accessed scan {scan.id} owned by {scan.user_id}",
                action="account_banned"
            )
            return jsonify({"error": "Account suspended."}), 403

        # ---- Decrypt the scan data ----
        decrypted_data = None
        if scan.scan_data:
            try:
                decrypted_bytes = cipher.decrypt(scan.scan_data.encode("utf-8"))
                decrypted_data = json.loads(decrypted_bytes.decode("utf-8"))
            except Exception:
                decrypted_data = None  # Handle corrupted/old data gracefully

        history_list.append({
            "id": scan.id,
            "target_url": scan.target_url,
            "scan_type": scan.scan_type,
            "status": scan.status,
            "risk_level": scan.risk_level,
            "created_at": scan.created_at.isoformat(),
            "completed_at": scan.completed_at.isoformat() if scan.completed_at else None,
            "results": decrypted_data
        })

    return jsonify({
        "scans": history_list,
        "total": len(history_list)
    }), 200


# ============================================================
# DELETE /api/history/<scan_id>
# ============================================================
@history_bp.route("/<scan_id>", methods=["DELETE"])
@login_required
@require_history_verified
def delete_scan(scan_id: str):
    """
    Soft-delete a scan from history.
    Sets deleted=True — data is kept for audit trail.

    SECURITY: Verify ownership. Accessing another user's scan = instant ban.
    """
    # Validate scan_id format (should be UUID4)
    import re
    uuid_pattern = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$', re.I)
    if not uuid_pattern.match(str(scan_id)):
        return jsonify({"error": "Invalid scan ID"}), 400

    scan = ScanHistory.query.get(scan_id)

    if not scan or scan.deleted:
        return jsonify({"error": "Scan not found"}), 404

    # ---- CRITICAL ownership verification ----
    if scan.user_id != current_user.id:
        _ban_and_log(
            user=current_user,
            ip=get_remote_address(),
            reason="Attempted to delete another user's scan",
            incident_type="unauthorized_history_access",
            severity="critical",
            details=f"User {current_user.id} tried to delete scan {scan_id} owned by {scan.user_id}",
            action="account_banned"
        )
        return jsonify({"error": "Account suspended."}), 403

    # ---- Soft delete ----
    scan.deleted = True
    scan.deleted_at = datetime.utcnow()
    db.session.commit()

    return jsonify({"message": "Scan deleted successfully"}), 200


# ============================================================
# HELPER: Mask email for display
# ============================================================
def _mask_email(email: str) -> str:
    """
    Partially hide email for security: john@example.com → j***@example.com
    So the user knows which email to check without fully exposing it in API response.
    """
    try:
        local, domain = email.split("@")
        masked_local = local[0] + "***"
        return f"{masked_local}@{domain}"
    except Exception:
        return "***@***"
