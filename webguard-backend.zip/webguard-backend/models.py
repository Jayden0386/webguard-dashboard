# =============================================================
#  models.py — Database Models
#  FILE: webguard-backend/models.py
# =============================================================
#
#  WHY UUID primary keys?
#    Integer IDs (1, 2, 3...) let attackers guess other users'
#    scan records. UUID4 is random — practically impossible to guess.
#
#  WHY encrypted scan data?
#    Even if someone steals the .db file, they can't read scan
#    results without the ENCRYPTION_KEY stored separately in .env
# =============================================================

import uuid
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin

db = SQLAlchemy()


def generate_uuid():
    """Generate a UUID4 string for use as a primary key."""
    return str(uuid.uuid4())


# ------------------------------------------------------------------
#  User — all registered accounts
# ------------------------------------------------------------------
class User(UserMixin, db.Model):
    __tablename__ = "users"

    # UUID primary key — prevents ID enumeration attacks
    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)

    email = db.Column(db.String(255), unique=True, nullable=False)

    # NEVER plain text — always bcrypt hash
    password_hash = db.Column(db.String(255), nullable=False)

    # "user" or "owner"
    role = db.Column(db.String(20), nullable=False, default="user")

    # User must accept disclaimer before scanning
    disclaimer_accepted = db.Column(db.Boolean, default=False)

    # Auto-ban counters
    failed_login_count = db.Column(db.Integer, default=0)
    failed_history_verify_count = db.Column(db.Integer, default=0)

    # ISO datetime string — when history unlocks after 30-min lock
    history_locked_until = db.Column(db.String(50), nullable=True)

    # Soft ban — never hard delete users
    is_banned = db.Column(db.Boolean, default=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Owner-only 2FA fields
    totp_secret = db.Column(db.String(64), nullable=True)
    failed_2fa_count = db.Column(db.Integer, default=0)
    two_fa_locked_until = db.Column(db.String(50), nullable=True)

    # One user → many scans
    scans = db.relationship("ScanHistory", backref="owner", lazy=True)

    def __repr__(self):
        return f"<User {self.email} role={self.role}>"


# ------------------------------------------------------------------
#  ScanHistory — Fernet-encrypted scan results
# ------------------------------------------------------------------
class ScanHistory(db.Model):
    __tablename__ = "scan_history"

    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)

    user_id = db.Column(db.String(36), db.ForeignKey("users.id"), nullable=False)

    target_url = db.Column(db.String(2048), nullable=False)

    # Scan result JSON stored as Fernet-encrypted base64 string
    # Unreadable without ENCRYPTION_KEY from .env
    encrypted_result = db.Column(db.Text, nullable=False)

    scan_type = db.Column(db.String(20), default="full")

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Soft delete — keeps audit trail; never shown to users
    deleted = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return f"<ScanHistory id={self.id} url={self.target_url}>"


# ------------------------------------------------------------------
#  BannedUser — permanently suspended accounts
# ------------------------------------------------------------------
class BannedUser(db.Model):
    __tablename__ = "banned_users"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id"), nullable=False)
    reason = db.Column(db.String(500), nullable=False)
    banned_at = db.Column(db.DateTime, default=datetime.utcnow)


# ------------------------------------------------------------------
#  BannedIP — blacklisted IP addresses
# ------------------------------------------------------------------
class BannedIP(db.Model):
    __tablename__ = "banned_ips"

    id = db.Column(db.Integer, primary_key=True)
    # String(45) supports both IPv4 and IPv6
    ip_address = db.Column(db.String(45), unique=True, nullable=False)
    reason = db.Column(db.String(500), nullable=False)
    banned_at = db.Column(db.DateTime, default=datetime.utcnow)


# ------------------------------------------------------------------
#  SecurityIncident — full audit log of every threat event
# ------------------------------------------------------------------
class SecurityIncident(db.Model):
    __tablename__ = "security_incidents"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(36), nullable=True)   # null if not logged in
    ip_address = db.Column(db.String(45), nullable=False)
    incident_type = db.Column(db.String(100), nullable=False)
    # e.g. "SQL_INJECTION", "SSRF_ATTEMPT", "IDOR_ATTACK"
    details = db.Column(db.Text, nullable=True)
    occurred_at = db.Column(db.DateTime, default=datetime.utcnow)
