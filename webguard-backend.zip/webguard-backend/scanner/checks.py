# =============================================================
#  scanner/checks.py — Surface Scan Functions
#  FILE: webguard-backend/scanner/checks.py
# =============================================================
#
#  SURFACE SCAN = visible issues found in a single HTTP request.
#  We inspect:
#    - Response headers (security headers missing?)
#    - Cookies (missing Secure/HttpOnly/SameSite flags?)
#    - HTML body (risky inline scripts, unprotected forms?)
#    - URL structure (SQL injection parameter hints?)
#
#  ETHICAL REMINDER: Only scan sites you own or have written
#  permission to test. Unauthorized scanning is illegal.
# =============================================================

import requests
from bs4 import BeautifulSoup
import re

REQUEST_TIMEOUT = 10  # seconds before we give up on a slow target

# Every production website should have ALL of these headers
REQUIRED_SECURITY_HEADERS = [
    "Content-Security-Policy",
    "Strict-Transport-Security",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
    "Permissions-Policy",
]


def run_surface_scan(url: str) -> dict:
    """
    Run all surface-level checks on a URL.
    Returns: { findings: [...], score: 0-100, checks_run: int }
    Higher score = more secure site.
    """
    findings = []
    score = 100  # Start perfect, deduct for each problem found

    try:
        response = requests.get(
            url,
            timeout=REQUEST_TIMEOUT,
            allow_redirects=True,
            headers={"User-Agent": "Mozilla/5.0 (WebGuard Security Scanner / Authorized)"},
            verify=True,  # Always verify TLS — never disable this
        )
    except requests.exceptions.SSLError:
        findings.append({
            "type": "SSL_ERROR",
            "severity": "CRITICAL",
            "message": "TLS/SSL certificate error — the HTTPS connection failed.",
            "detail": "Obtain a valid certificate from a trusted CA (e.g. Let's Encrypt).",
        })
        return {"findings": findings, "score": 0, "error": "ssl_error"}
    except requests.exceptions.ConnectionError:
        return {"findings": [], "score": 0, "error": "connection_failed"}
    except requests.exceptions.Timeout:
        return {"findings": [], "score": 0, "error": "timeout"}
    except Exception:
        # Never leak exception details to the caller
        return {"findings": [], "score": 0, "error": "request_failed"}

    headers = response.headers

    # ----------------------------------------------------------
    #  CHECK 1: Missing Security Headers
    # ----------------------------------------------------------
    for header in REQUIRED_SECURITY_HEADERS:
        if header not in headers:
            findings.append({
                "type": "MISSING_HEADER",
                "severity": "MEDIUM",
                "message": f"Missing security header: {header}",
                "detail": f"Add the '{header}' header to all HTTP responses.",
            })
            score -= 5

    # ----------------------------------------------------------
    #  CHECK 2: HTTP instead of HTTPS
    # ----------------------------------------------------------
    if response.url.startswith("http://"):
        findings.append({
            "type": "NO_HTTPS",
            "severity": "HIGH",
            "message": "Site is not using HTTPS. All traffic is sent in plaintext.",
            "detail": "Get a free TLS cert from Let's Encrypt and redirect all HTTP → HTTPS.",
        })
        score -= 20

    # ----------------------------------------------------------
    #  CHECK 3: Server / Framework Version Disclosure
    #  "Server: Apache/2.4.51" tells attackers which CVEs apply
    # ----------------------------------------------------------
    server = headers.get("Server", "")
    x_powered = headers.get("X-Powered-By", "")

    if server:
        findings.append({
            "type": "SERVER_DISCLOSURE",
            "severity": "LOW",
            "message": f"Server header reveals software: '{server}'",
            "detail": "Configure your server to hide or genericize the Server header.",
        })
        score -= 5

    if x_powered:
        findings.append({
            "type": "FRAMEWORK_DISCLOSURE",
            "severity": "LOW",
            "message": f"X-Powered-By header exposes tech stack: '{x_powered}'",
            "detail": "Remove the X-Powered-By header entirely.",
        })
        score -= 5

    # ----------------------------------------------------------
    #  CHECK 4: Insecure Cookie Flags
    #  Cookies without these flags can be stolen or forged
    # ----------------------------------------------------------
    set_cookie = headers.get("Set-Cookie", "")
    if set_cookie:
        if "Secure" not in set_cookie:
            findings.append({
                "type": "COOKIE_NO_SECURE",
                "severity": "MEDIUM",
                "message": "Cookie missing the 'Secure' flag — can be sent over HTTP.",
                "detail": "Add 'Secure' so cookies only travel over HTTPS connections.",
            })
            score -= 8

        if "HttpOnly" not in set_cookie:
            findings.append({
                "type": "COOKIE_NO_HTTPONLY",
                "severity": "MEDIUM",
                "message": "Cookie missing 'HttpOnly' — JavaScript can read it.",
                "detail": "Add 'HttpOnly' to prevent XSS attacks from stealing cookies.",
            })
            score -= 8

        if "SameSite" not in set_cookie:
            findings.append({
                "type": "COOKIE_NO_SAMESITE",
                "severity": "LOW",
                "message": "Cookie missing 'SameSite' attribute — CSRF risk.",
                "detail": "Add 'SameSite=Strict' or 'SameSite=Lax' to prevent CSRF.",
            })
            score -= 4

    # ----------------------------------------------------------
    #  CHECK 5: XSS Indicators in HTML
    # ----------------------------------------------------------
    try:
        soup = BeautifulSoup(response.text, "html.parser")

        # Inline event handlers like onclick="..." are XSS hotspots
        risky_elements = soup.find_all(
            True,
            attrs=lambda a: a and any(k.startswith("on") for k in a.keys()),
        )
        if risky_elements:
            findings.append({
                "type": "XSS_INLINE_HANDLERS",
                "severity": "MEDIUM",
                "message": f"Found {len(risky_elements)} inline event handler(s) (onclick, onload, etc.)",
                "detail": "Move handlers to external JS. Use CSP to block inline scripts.",
            })
            score -= 8

        # Forms without CSRF tokens are vulnerable to CSRF attacks
        forms = soup.find_all("form")
        unprotected = sum(
            1 for f in forms
            if not f.find("input", attrs={"name": re.compile(r"csrf|token|_token", re.I)})
        )
        if unprotected:
            findings.append({
                "type": "CSRF_NO_TOKEN",
                "severity": "HIGH",
                "message": f"{unprotected} form(s) found without a CSRF token.",
                "detail": "Add anti-CSRF tokens to all state-changing forms.",
            })
            score -= 10

    except Exception:
        pass  # HTML parse failure is non-fatal

    # ----------------------------------------------------------
    #  CHECK 6: SQL Injection Hints in URL Parameters
    #  ?id=1 or ?user=admin are common SQLi targets
    # ----------------------------------------------------------
    risky_params = re.compile(
        r"[?&](id|user|username|name|search|query|q|page|cat|item|product)=",
        re.IGNORECASE,
    )
    if risky_params.search(url):
        findings.append({
            "type": "SQLI_HINT_URL",
            "severity": "INFO",
            "message": "URL contains parameter names commonly targeted in SQL injection.",
            "detail": "Verify all DB queries use parameterized statements, not string formatting.",
        })
        score -= 3

    # ----------------------------------------------------------
    #  CHECK 7: Open Redirect Links
    #  /redirect?url=https://evil.com can be abused in phishing
    # ----------------------------------------------------------
    if re.search(
        r'href=["\'].*?(redirect|return|next|url|goto|target)=https?://',
        response.text, re.IGNORECASE
    ):
        findings.append({
            "type": "OPEN_REDIRECT",
            "severity": "MEDIUM",
            "message": "Possible open redirect link found in page source.",
            "detail": "Validate all redirect destinations against a whitelist of allowed domains.",
        })
        score -= 8

    return {
        "findings": findings,
        "score": max(0, min(100, score)),
        "checks_run": 7,
        "http_status": response.status_code,
        "final_url": response.url,
    }
