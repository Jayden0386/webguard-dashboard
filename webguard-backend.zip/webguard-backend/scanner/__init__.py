# scanner/__init__.py
# Makes 'scanner' a Python package.
# Usage:
#   from scanner.checks import run_surface_scan
#   from scanner.deep_checks import run_deep_scan
