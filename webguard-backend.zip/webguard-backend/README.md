# WebGuard Scanner — Flask Backend

A professional web vulnerability scanner backend for a Level 200 Cybersecurity final year project.

---

## Project Structure

```
webguard-backend/
├── .env.example          ← Copy to .env and fill in secrets
├── .gitignore            ← Protects .env, *.db, QR codes from git
├── app.py                ← Main Flask app, security headers, ban system
├── models.py             ← Database models (User, ScanHistory, etc.)
├── create_owner.py       ← One-time owner account + 2FA setup
├── requirements.txt      ← All dependencies (pinned versions)
├── routes/
│   ├── auth.py           ← Register, login, logout, disclaimer
│   ├── scan.py           ← Vulnerability scan endpoint
│   ├── history.py        ← Scan history with OTP verification
│   └── owner.py          ← Owner 2FA + admin dashboard
└── scanner/
    ├── checks.py         ← Surface scan (headers, cookies, XSS, etc.)
    └── deep_checks.py    ← Deep scan (files, admin panels, TLS, etc.)
```

---

## Quick Start

### 1. Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate        # Linux/Mac
venv\Scripts\activate           # Windows
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Set up your .env file
```bash
cp .env.example .env
```

Then edit `.env` and fill in:
- `SECRET_KEY` — generate with: `python -c "import secrets; print(secrets.token_hex(32))"`
- `ENCRYPTION_KEY` — generate with: `python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`
- `MAIL_USERNAME` and `MAIL_PASSWORD` — Gmail app password for sending OTPs
- `FLASK_ENV` — set to `development` locally, `production` when deployed

### 4. Create the owner account
```bash
python create_owner.py
```

Follow the prompts. Scan the QR code with Google Authenticator or Authy.

### 5. Run the backend
```bash
python app.py
```

The API will be available at `http://localhost:5000`

---

## API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Create new account |
| POST | `/api/auth/login` | Login (returns session) |
| POST | `/api/auth/logout` | Logout (clears session) |
| POST | `/api/auth/disclaimer` | Accept ethical use disclaimer |
| GET  | `/api/auth/me` | Get current user info |

### Scanning
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/scan` | Run full vulnerability scan |

**Request body:**
```json
{
  "url": "https://example.com"
}
```

**Rate limit:** 5 scans per hour per user.
**Requires:** Login + disclaimer accepted.

### Scan History (requires 3-step verification)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/history/verify-password` | Step 1: Re-verify password |
| POST | `/api/history/send-otp` | Step 2: Send OTP to email |
| POST | `/api/history/verify-otp` | Step 3: Verify OTP (grants 10-min access) |
| GET  | `/api/history` | List your scan history |
| DELETE | `/api/history/<id>` | Delete a scan (soft delete) |

### Owner Panel (requires password + TOTP 2FA)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/owner/verify-2fa` | Complete owner 2FA login |
| GET  | `/api/owner/stats` | System overview |
| GET  | `/api/owner/users` | All user accounts |
| GET  | `/api/owner/bans` | Banned users + IPs |
| GET  | `/api/owner/incidents` | Security incident log |
| POST | `/api/owner/lift-ban` | Lift a user ban (requires fresh 2FA) |

---

## Security Features

### Auto-Ban System
The system automatically bans accounts that:
- Send SQL injection patterns in any input
- Try to access `.env`, `.git`, `/config`, `/database`
- Tamper with session data
- Try to access another user's scan history
- Send SSRF targets (private IPs) to the scan endpoint
- Exceed 10 failed login attempts
- Exceed 5 failed history verifications

**All bans:** User account disabled + IP blacklisted + SecurityIncident logged

### Scan History Protection
Accessing history requires:
1. Password re-verification
2. OTP code sent to registered email
3. Access granted for 10 minutes only

### Owner 2FA
- TOTP (Time-based One-Time Password) via pyotp
- 6-digit codes, 30-second window
- Wrong code 3 times = 1-hour lockout
- Session bound to IP address
- Session expires after 15 minutes

### Encryption
- All scan results encrypted with Fernet (AES-128-CBC) before database storage
- Only decrypted on verified access
- Encryption key stored in `.env` only

---

## ETHICAL USE — IMPORTANT

> ⚠️ **Only scan websites that you OWN or have EXPLICIT WRITTEN PERMISSION to test.**
>
> Unauthorized scanning is illegal under computer crime laws in most countries.
> This tool is for educational purposes and authorized security assessments only.
> Misuse may result in criminal charges.

---

## Connecting to Lovable Frontend

Your React frontend needs to make API calls with credentials:

```javascript
// In your Lovable frontend API calls:
const response = await fetch("http://localhost:5000/api/auth/login", {
  method: "POST",
  credentials: "include",           // ← Required for session cookies
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ username, password })
});
```

Set `FRONTEND_URL` in your `.env` to your Lovable app's URL for production CORS.

---

## Week-by-Week Build Plan

- **Week 3–4:** Auth system (register, login, logout, disclaimer) ✅
- **Week 5–6:** Scanning + SSRF protection + auto-ban system ✅
- **Week 7:** Owner 2FA + history verification ✅
- **Week 8:** Polish, testing, deployment prep
