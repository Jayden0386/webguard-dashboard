# WebGuard Scanner — Backend
### Final Year Project | Level 200 Cybersecurity | Web Application Security

---

## Folder Structure

```
webguard-backend/
├── routes/
│   ├── __init__.py
│   ├── auth.py          ← Register, Login, Logout, Disclaimer, Status
│   ├── scan.py          ← Run surface + deep + hacker intel scan
│   ├── history.py       ← View, verify, delete scan history
│   └── owner.py         ← Owner 2FA, stats, users, bans, incidents
├── scanner/
│   ├── __init__.py
│   ├── checks.py        ← Surface scan (7 checks)
│   ├── deep_checks.py   ← Deep/hidden scan (12 checks)
│   └── hacker_intel.py  ← Hacker tool intelligence (8 tools simulated)
├── .env.example         ← Copy to .env and fill in your values
├── .gitignore           ← Protects secrets from being committed
├── app.py               ← Flask app factory, security headers, threat detection
├── create_owner.py      ← Run once to create owner account + 2FA QR
├── extensions.py        ← Flask extension instances
├── models.py            ← Database models (User, ScanHistory, BannedUser, etc.)
├── README.md            ← This file
├── requirements.txt     ← All Python dependencies
└── security.py          ← Shared helpers: encryption, SSRF, SQLi detection
```

---

## Setup & Run

### Step 1 — Install dependencies
```bash
pip install -r requirements.txt
```

### Step 2 — Create your .env file
```bash
cp .env.example .env
```
Then edit `.env` and fill in:
- `SECRET_KEY` — generate with: `python -c "import secrets; print(secrets.token_hex(32))"`
- `ENCRYPTION_KEY` — generate with: `python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`
- `OWNER_EMAIL` and `OWNER_PASSWORD` — your owner account credentials
- Mail settings for OTP emails

### Step 3 — Create the owner account (run ONCE only)
```bash
python create_owner.py
```
This will:
- Create the owner account in the database
- Generate a 2FA QR code → `owner_2fa_qr.png`
- Scan the QR code with Google Authenticator or Authy
- **Delete `owner_2fa_qr.png` immediately after scanning**

### Step 4 — Start the server
```bash
python app.py
```
Server runs at: `http://localhost:5000`

---

## API Endpoints

### Auth
| Method | Route | Description |
|--------|-------|-------------|
| POST | /api/auth/register | Create new account |
| POST | /api/auth/login | Login (owner → 2FA step) |
| POST | /api/auth/logout | Clear session |
| POST | /api/auth/disclaimer | Accept ethical use terms |
| GET  | /api/auth/status | Check current session state |

### Scanning
| Method | Route | Description |
|--------|-------|-------------|
| POST | /api/scan | Run full scan (surface + deep + hacker intel) |

### History
| Method | Route | Description |
|--------|-------|-------------|
| POST | /api/history/verify-password | Step 1: re-verify password |
| POST | /api/history/send-otp | Step 2: send OTP to email |
| POST | /api/history/verify-otp | Step 3: verify OTP code |
| GET  | /api/history | Get user's scan history |
| DELETE | /api/history/\<scan_id\> | Soft-delete a scan |

### Owner (requires 2FA)
| Method | Route | Description |
|--------|-------|-------------|
| POST | /api/owner/verify-2fa | Complete owner login with TOTP |
| GET  | /api/owner/stats | System overview stats |
| GET  | /api/owner/users | All user accounts |
| GET  | /api/owner/bans | Banned accounts + IPs |
| GET  | /api/owner/incidents | Security incident log |
| POST | /api/owner/lift-ban | Lift a ban (needs fresh 2FA) |

---

## Security Features
- Bcrypt password hashing (cost factor 12)
- Fernet AES encryption for all scan results
- UUID primary keys (prevents enumeration)
- Auto-ban threat detection (SQLi, SSRF, IDOR, session tampering)
- Owner 2FA with TOTP (pyotp + Google Authenticator)
- History re-verification with OTP before access
- Rate limiting on all sensitive endpoints
- Security headers on every response
- SSRF protection (blocks internal IP scan targets)
- Soft deletes (audit trail preserved)

---

## Ethical Notice
This tool is for **educational purposes only**.
Only scan websites you own or have **explicit written permission** to test.
Unauthorized scanning is illegal.

---

*WebGuard Scanner — Level 200 Cybersecurity Final Year Project*
