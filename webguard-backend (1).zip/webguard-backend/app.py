# =============================================================
#  app.py — WebGuard Scanner: Main Flask Application
#  FILE: webguard-backend/app.py
# =============================================================
#
#  HOW TO RUN:
#    1. pip install -r requirements.txt
#    2. Copy .env.example to .env and fill in values
#    3. python app.py                 ← starts the server
#    4. python create_owner.py        ← run once to create owner account
#
#  WHAT THIS FILE DOES:
#    1. Creates and configures the Flask app
#    2. Applies security headers to every response (after_request)
#    3. Runs auto-ban threat detection before every request (before_request)
#    4. Registers all route blueprints
#
#  KEY SECURITY RULES:
#    a) No stack traces ever — custom error handlers only
#    b) All secrets from .env — nothing hardcoded
#    c) bcrypt for passwords — never MD5/SHA1/plain
#    d) Fernet AES for scan data — encrypted before DB storage
#    e) UUID primary keys — prevents enumeration
#    f) SQLAlchemy ORM — parameterized queries, no raw SQL
#    g) SSRF guard — internal IPs blocked from scan endpoint
#    h) Rate limiting — brute force and scan abuse prevention
# =============================================================

import os
import re
import socket
import json
from functools import wraps
from datetime import datetime, timedelta, timezone

from flask import Flask, request, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_required, current_user
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_cors import CORS
from flask_mail import Mail
from cryptography.fernet import Fernet
from dotenv import load_dotenv

from models import db, User, BannedIP, BannedUser, SecurityIncident
from routes.auth import auth_bp
from routes.scan import scan_bp
from routes.history import history_bp
from routes.owner import owner_bp

load_dotenv()


def create_app():
    app = Flask(__name__)

    # ----------------------------------------------------------
    #  Core Config
    # ----------------------------------------------------------
    secret = os.environ.get("SECRET_KEY", "")
    if not secret:
        raise RuntimeError("SECRET_KEY missing from .env — refusing to start.")
    app.config["SECRET_KEY"] = secret

    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///webguard.db"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # Session cookie hardening
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    app.config["SESSION_COOKIE_SECURE"] = (
        os.environ.get("FLASK_ENV") == "production"
    )
    app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=2)

    # Flask-Mail
    app.config["MAIL_SERVER"]         = os.environ.get("MAIL_SERVER", "smtp.gmail.com")
    app.config["MAIL_PORT"]           = int(os.environ.get("MAIL_PORT", 587))
    app.config["MAIL_USE_TLS"]        = os.environ.get("MAIL_USE_TLS", "True") == "True"
    app.config["MAIL_USERNAME"]       = os.environ.get("MAIL_USERNAME")
    app.config["MAIL_PASSWORD"]       = os.environ.get("MAIL_PASSWORD")
    app.config["MAIL_DEFAULT_SENDER"] = os.environ.get("MAIL_USERNAME")

    # ----------------------------------------------------------
    #  Init Extensions
    # ----------------------------------------------------------
    db.init_app(app)
    mail = Mail(app)

    login_manager = LoginManager(app)
    login_manager.session_protection = "strong"

    enc_key = os.environ.get("ENCRYPTION_KEY", "")
    if not enc_key:
        raise RuntimeError("ENCRYPTION_KEY missing from .env — refusing to start.")

    limiter = Limiter(
        get_remote_address,
        app=app,
        default_limits=["200 per day", "50 per hour"],
        storage_uri="memory://",
    )

    # CORS — only allow your React frontend origins
    CORS(app, resources={r"/api/*": {
        "origins": [
            "http://localhost:5173",           # Vite dev server
            "https://your-app.lovable.app",    # Replace with your real Lovable URL
        ],
        "supports_credentials": True,
    }})

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(user_id)

    @login_manager.unauthorized_handler
    def unauthorized():
        return jsonify({"error": "Authentication required."}), 401

    # ----------------------------------------------------------
    #  Register Route Blueprints
    # ----------------------------------------------------------
    app.register_blueprint(auth_bp)
    app.register_blueprint(scan_bp)
    app.register_blueprint(history_bp)
    app.register_blueprint(owner_bp)

    # Pass shared objects to blueprints via app config
    app.config["MAIL_INSTANCE"]   = mail
    app.config["LIMITER_INSTANCE"] = limiter
    app.config["FERNET_KEY"]      = enc_key

    # ==========================================================
    #  SECURITY HEADERS — applied to every single response
    # ==========================================================
    @app.after_request
    def set_security_headers(response):
        response.headers["X-Frame-Options"]           = "DENY"
        response.headers["X-Content-Type-Options"]    = "nosniff"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Referrer-Policy"]           = "no-referrer"
        response.headers["Permissions-Policy"]        = "geolocation=(), microphone=(), camera=()"
        response.headers["Content-Security-Policy"]   = (
            "default-src 'self'; "
            "script-src 'self'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; "
            "connect-src 'self'"
        )
        # NEVER expose Flask/Werkzeug version to attackers
        response.headers["Server"] = "WebGuard"
        return response

    # ==========================================================
    #  AUTO-BAN THREAT DETECTION — runs before every request
    # ==========================================================

    # SQL injection signatures
    _SQLI = re.compile(
        r"(\b(union\s+select|drop\s+table|insert\s+into|exec\s*\(|"
        r"xp_cmdshell|information_schema)\b"
        r"|'\s*(or|and)\s*'?\d'?\s*=\s*'?\d"
        r"|--\s*$|;\s*drop\b)",
        re.IGNORECASE,
    )

    # Paths attackers probe looking for config/credential files
    _SENSITIVE = re.compile(
        r"^(/\.env|/\.git|/config|/database|/backup|/db\.sqlite|/wp-config)",
        re.IGNORECASE,
    )

    def _ip():
        return (
            request.headers.get("X-Forwarded-For", request.remote_addr)
            .split(",")[0].strip()
        )

    def _ban(user_id, ip, reason, incident_type, details):
        """Permanently ban a user account and IP. Log the full incident."""
        inc = SecurityIncident(
            user_id=user_id,
            ip_address=ip,
            incident_type=incident_type,
            details=details,
        )
        db.session.add(inc)
        if user_id:
            u = User.query.get(user_id)
            if u and not u.is_banned:
                u.is_banned = True
                db.session.add(BannedUser(user_id=user_id, reason=reason))
        if not BannedIP.query.filter_by(ip_address=ip).first():
            db.session.add(BannedIP(ip_address=ip, reason=reason))
        db.session.commit()
        session.clear()

    def _suspended():
        """Opaque response — never reveals detection reason to attacker."""
        return jsonify({"error": "Account suspended."}), 403

    @app.before_request
    def threat_detection():
        ip = _ip()

        # 1. Banned IP check
        if BannedIP.query.filter_by(ip_address=ip).first():
            return _suspended()

        # 2. Banned user check
        if current_user.is_authenticated and current_user.is_banned:
            session.clear()
            return _suspended()

        # 3. Sensitive path probing (/.env, /.git, etc.)
        if _SENSITIVE.search(request.path):
            uid = current_user.id if current_user.is_authenticated else None
            _ban(uid, ip, "Sensitive path probe", "PATH_PROBE",
                 f"Path: {request.path}")
            return _suspended()

        # 4. SQL injection in query string
        for k, v in request.args.items():
            if _SQLI.search(str(v)) or _SQLI.search(str(k)):
                uid = current_user.id if current_user.is_authenticated else None
                _ban(uid, ip, "SQL injection in query string", "SQL_INJECTION",
                     f"{k}={str(v)[:200]}")
                return _suspended()

        # 5. SQL injection in JSON body
        if request.is_json:
            body = request.get_json(silent=True) or {}
            for k, v in body.items():
                if _SQLI.search(str(v)) or _SQLI.search(str(k)):
                    uid = current_user.id if current_user.is_authenticated else None
                    _ban(uid, ip, "SQL injection in request body", "SQL_INJECTION",
                         f"key={k} value={str(v)[:200]}")
                    return _suspended()

        # 6. history_verified must be exactly boolean True
        #    Anything else = tampered session cookie
        if "history_verified" in session:
            if session.get("history_verified") is not True:
                uid = current_user.id if current_user.is_authenticated else None
                _ban(uid, ip, "Session tampering", "SESSION_TAMPER",
                     "history_verified was not boolean True")
                return _suspended()

        # 7. Auto-expire history_verified after 10 minutes
        if session.get("history_verified"):
            ts = session.get("history_verified_at")
            if ts:
                dt = datetime.fromisoformat(ts)
                if datetime.now(timezone.utc) - dt > timedelta(minutes=10):
                    session.pop("history_verified", None)
                    session.pop("history_verified_at", None)

    # ==========================================================
    #  CUSTOM ERROR HANDLERS
    #  Default Flask errors show stack traces — never do that
    # ==========================================================
    @app.errorhandler(400)
    def bad_request(_):
        return jsonify({"error": "Bad request."}), 400

    @app.errorhandler(404)
    def not_found(_):
        return jsonify({"error": "Not found."}), 404

    @app.errorhandler(405)
    def method_not_allowed(_):
        return jsonify({"error": "Method not allowed."}), 405

    @app.errorhandler(429)
    def rate_limited(_):
        return jsonify({"error": "Too many requests. Please slow down."}), 429

    @app.errorhandler(500)
    def internal_error(_):
        # NEVER include exception details here
        return jsonify({"error": "An internal error occurred."}), 500

    # Create all DB tables on first run
    with app.app_context():
        db.create_all()

    return app


# =============================================================
#  Entry Point
# =============================================================
if __name__ == "__main__":
    application = create_app()
    # debug=False is CRITICAL — debug=True exposes an interactive
    # Python shell in the browser — a catastrophic vulnerability
    application.run(debug=False, host="127.0.0.1", port=5000)
