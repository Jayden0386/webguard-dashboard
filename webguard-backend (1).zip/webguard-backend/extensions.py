# =============================================================
#  extensions.py — Flask Extensions
#  FILE: webguard-backend/extensions.py
# =============================================================
#
#  Extensions initialized here to avoid circular imports.
#  app.py imports these and calls init_app() on each.
# =============================================================

from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_cors import CORS
from flask_mail import Mail

db           = SQLAlchemy()
login_manager = LoginManager()
limiter      = Limiter(key_func=get_remote_address)
cors         = CORS()
mail         = Mail()
