# =============================================================
#  security.py — Shared Security Helpers
#  FILE: webguard-backend/security.py
# =============================================================
#
#  Contains: Fernet encryption, SSRF protection, SQL injection
#  detection, session validation, history helpers, client IP.
#  Import these into routes — do NOT duplicate logic.
# =============================================================

import os
import re
import json
import socket
import ipaddress
from datetime import datetime, timedelta, timezone
from flask import request, session
from cryptography.fernet import Fernet


# ------------------------------------------------------------------
#  Fernet AES Encryption — scan results stored encrypted in DB
# ------------------------------------------------------------------

def get_fernet() -> Fernet:
    """Return a Fernet instance using ENCRYPTION_KEY from .env."""
    key = os.environ.get("ENCRYPTION_KEY")
    if not key:
        raise RuntimeError("ENCRYPTION_KEY not set in .env")
    return Fernet(key.encode())


def encrypt_data(data: dict) -> str:
    """Serialize dict to JSON and AES-encrypt. Returns base64 string."""
    return get_fernet().encrypt(json.dumps(data).encode()).decode()


def decrypt_data(token: str) -> dict:
    """Decrypt a Fernet token and return the original dict."""
    return json.loads(get_fernet().decrypt(token.encode()).decode())


# ------------------------------------------------------------------
#  SSRF Protection — reject internal/private IPs as scan targets
# ------------------------------------------------------------------

BLOCKED_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),    # loopback
    ipaddress.ip_network("10.0.0.0/8"),     # private class A
    ipaddress.ip_network("172.16.0.0/12"),  # private class B
    ipaddress.ip_network("192.168.0.0/16"), # private class C
    ipaddress.ip_network("169.254.0.0/16"), # link-local
    ipaddress.ip_network("::1/128"),        # IPv6 loopback
    ipaddress.ip_network("fc00::/7"),       # IPv6 private
]


def is_ssrf_target(hostname: str) -> bool:
    """
    Returns True if the hostname resolves to a private/internal IP.
    Call before EVERY scan request.
    If True → reject scan and ban the user.
    """
    try:
        ip_str = socket.gethostbyname(hostname)
        ip = ipaddress.ip_address(ip_str)
        return any(ip in net for net in BLOCKED_NETWORKS)
    except (socket.gaierror, ValueError):
        return True  # Can't resolve = block it to be safe


# ------------------------------------------------------------------
#  SQL Injection Detection — check all incoming string values
# ------------------------------------------------------------------

SQL_INJECTION_PATTERNS = [
    r"'.*--",
    r"union\s+select",
    r"drop\s+table",
    r"insert\s+into",
    r"delete\s+from",
    r";\s*drop",
    r"1\s*=\s*1",
    r"or\s+1\s*=\s*1",
    r"'\s+or\s+'",
    r"exec\s*\(",
    r"xp_cmdshell",
    r"<script",
    r"javascript:",
]

COMPILED_SQL = [re.compile(p, re.IGNORECASE) for p in SQL_INJECTION_PATTERNS]


def contains_sql_injection(value: str) -> bool:
    """Return True if the string matches any SQL injection pattern."""
    return any(p.search(value) for p in COMPILED_SQL)


def _flatten_values(data, depth=0):
    """Recursively yield all string values from a dict/list (max 3 levels)."""
    if depth > 3:
        return
    if isinstance(data, dict):
        for v in data.values():
            yield from _flatten_values(v, depth + 1)
    elif isinstance(data, list):
        for item in data:
            yield from _flatten_values(item, depth + 1)
    else:
        yield data


def scan_request_for_sqli() -> bool:
    """Check all request values (JSON, args, form) for SQL injection."""
    if request.is_json:
        for v in _flatten_values(request.get_json(silent=True) or {}):
            if isinstance(v, str) and contains_sql_injection(v):
                return True
    for v in list(request.args.values()) + list(request.form.values()):
        if contains_sql_injection(v):
            return True
    return False


# ------------------------------------------------------------------
#  Sensitive Path Detection
# ------------------------------------------------------------------

SENSITIVE_PATHS = [
    r"/\.env", r"/\.git", r"/config", r"/database",
    r"/backup", r"/wp-config", r"/phpinfo", r"\.sql$", r"/admin/\?",
]
COMPILED_PATHS = [re.compile(p, re.IGNORECASE) for p in SENSITIVE_PATHS]


def is_probing_sensitive_path(path: str) -> bool:
    """Return True if the request path looks like an attacker probe."""
    return any(p.search(path) for p in COMPILED_PATHS)


# ------------------------------------------------------------------
#  History Session Validation
# ------------------------------------------------------------------

def is_history_session_valid() -> bool:
    """
    Return True only if history was verified AND not expired (10 min).
    Clears session flags if expired.
    """
    if not session.get("history_verified"):
        return False
    verified_at = session.get("history_verified_at")
    if not verified_at:
        return False
    try:
        dt = datetime.fromisoformat(verified_at)
        if datetime.now(timezone.utc) - dt > timedelta(minutes=10):
            session.pop("history_verified", None)
            session.pop("history_verified_at", None)
            return False
    except (ValueError, TypeError):
        return False
    return True


def set_history_verified():
    """Set history as verified for 10 minutes."""
    session["history_verified"]    = True
    session["history_verified_at"] = datetime.now(timezone.utc).isoformat()


# ------------------------------------------------------------------
#  Client IP Helper
# ------------------------------------------------------------------

def get_client_ip() -> str:
    """Get the real client IP, respecting reverse proxies."""
    return (
        request.headers.get("X-Forwarded-For", request.remote_addr or "unknown")
        .split(",")[0].strip()
    )
