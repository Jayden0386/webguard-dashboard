# =============================================================
#  routes/history.py — Scan History Routes
#  FILE: webguard-backend/routes/history.py
# =============================================================
#
#  ROUTES:
#    POST /api/history/verify-password  ← step 1: re-verify password
#    POST /api/history/send-otp         ← step 2: send OTP to email
#    POST /api/history/verify-otp       ← step 3: verify OTP code
#    GET  /api/history                  ← get user's scan history
#    DELETE /api/history/<scan_id>      ← soft-delete a scan
#
#  SECURITY:
#    - History requires login + re-verification every time
#    - history_verified session expires after 10 minutes
#    - IDOR protection: user can only access their own scans
#    - 5 failed verifications → permanent ban
# =============================================================

import uuid
import json
import bcrypt
from datetime import datetime, timedelta, timezone
from flask import Blueprint, request, jsonify, session
from flask_login import login_required, current_user
from flask_mail import Message
from models import db, User, ScanHistory, BannedUser, BannedIP, SecurityIncident
from security import get_fernet, set_history_verified

history_bp = Blueprint("history", __name__)


def _ip():
    return (
        request.headers.get("X-Forwarded-For", request.remote_addr)
        .split(",")[0].strip()
    )


def _ban(user_id, ip, reason, incident_type, details):
    """Permanently ban a user and IP."""
    inc = SecurityIncident(
        user_id=user_id, ip_address=ip,
        incident_type=incident_type, details=details,
    )
    db.session.add(inc)
    if user_id:
        u = User.query.get(user_id)
        if u and not u.is_banned:
            u.is_banned = True
            db.session.add(BannedUser(user_id=user_id, reason=reason))
    if not BannedIP.query.filter_by(ip_address=ip).first():
        db.session.add(BannedIP(ip_address=ip, reason=reason))
    db.session.commit()
    session.clear()


# =============================================================
#  POST /api/history/verify-password
#  Step 1: Re-confirm password before sending OTP
# =============================================================
@history_bp.route("/api/history/verify-password", methods=["POST"])
@login_required
def history_verify_password():
    data     = request.get_json(silent=True) or {}
    password = str(data.get("password", ""))
    ip       = _ip()

    if not bcrypt.checkpw(password.encode(), current_user.password_hash.encode()):
        current_user.failed_history_verify_count += 1
        db.session.commit()
        count = current_user.failed_history_verify_count

        # Lock for 30 minutes after 3 failures
        if 3 <= count < 5:
            lock = datetime.now(timezone.utc) + timedelta(minutes=30)
            current_user.history_locked_until = lock.isoformat()
            db.session.commit()
            return jsonify({"error": "History locked for 30 minutes."}), 403

        # Permanent ban after 5 failures
        if count >= 5:
            _ban(current_user.id, ip,
                 "5 failed history verifications",
                 "HISTORY_BRUTE_FORCE",
                 f"Count: {count}")
            return jsonify({"error": "Account suspended."}), 403

        remaining = 3 - count if count < 3 else 0
        return jsonify({
            "error": "Incorrect password.",
            "attempts_remaining": max(0, remaining)
        }), 401

    # Password correct — reset counter
    current_user.failed_history_verify_count = 0
    db.session.commit()
    return jsonify({"message": "Password verified. Request OTP."}), 200


# =============================================================
#  POST /api/history/send-otp
#  Step 2: Generate and email a 6-digit OTP
# =============================================================
@history_bp.route("/api/history/send-otp", methods=["POST"])
@login_required
def history_send_otp():
    from flask import current_app
    mail = current_app.config.get("MAIL_INSTANCE")

    otp = str(uuid.uuid4().int)[:6]
    session["history_otp"]         = otp
    session["history_otp_expires"] = (
        datetime.now(timezone.utc) + timedelta(minutes=5)
    ).isoformat()

    try:
        if mail:
            mail.send(Message(
                subject="WebGuard — Your History Access Code",
                recipients=[current_user.email],
                body=(
                    f"Your one-time code: {otp}\n\n"
                    f"This code expires in 5 minutes.\n\n"
                    f"If you did not request this, change your password immediately."
                ),
            ))
    except Exception:
        # Log server-side in production; never expose mail errors to client
        pass

    return jsonify({"message": "OTP sent to your email."}), 200


# =============================================================
#  POST /api/history/verify-otp
#  Step 3: Verify the OTP → grant 10-minute history access
# =============================================================
@history_bp.route("/api/history/verify-otp", methods=["POST"])
@login_required
def history_verify_otp():
    data        = request.get_json(silent=True) or {}
    submitted   = str(data.get("otp", "")).strip()
    stored      = session.get("history_otp")
    expires_str = session.get("history_otp_expires")

    if not stored or not expires_str:
        return jsonify({"error": "No active OTP. Request a new one."}), 400

    if datetime.now(timezone.utc) > datetime.fromisoformat(expires_str):
        session.pop("history_otp", None)
        return jsonify({"error": "OTP expired. Request a new one."}), 400

    if submitted != stored:
        return jsonify({"error": "Invalid OTP."}), 401

    # Grant access for 10 minutes
    # history_verified MUST be boolean True — enforced in before_request
    set_history_verified()
    session.pop("history_otp", None)
    session.pop("history_otp_expires", None)

    return jsonify({"message": "Verified. History access granted for 10 minutes."}), 200


# =============================================================
#  GET /api/history
#  Returns the logged-in user's scan history (decrypted)
# =============================================================
@history_bp.route("/api/history", methods=["GET"])
@login_required
def get_history():
    # Must have completed re-verification
    if not session.get("history_verified"):
        return jsonify({"error": "Identity verification required."}), 403

    scans = (
        ScanHistory.query
        .filter_by(user_id=current_user.id, deleted=False)
        .order_by(ScanHistory.created_at.desc())
        .all()
    )

    results = []
    for s in scans:
        try:
            decrypted = json.loads(get_fernet().decrypt(s.encrypted_result.encode()))
        except Exception:
            continue  # Skip corrupted records silently
        results.append({
            "id":     s.id,
            "url":    s.target_url,
            "date":   s.created_at.isoformat(),
            "result": decrypted,
        })

    return jsonify({"scans": results}), 200


# =============================================================
#  DELETE /api/history/<scan_id>
#  Soft-delete a scan (keeps audit trail)
# =============================================================
@history_bp.route("/api/history/<scan_id>", methods=["DELETE"])
@login_required
def delete_history(scan_id):
    if not session.get("history_verified"):
        return jsonify({"error": "Identity verification required."}), 403

    scan = ScanHistory.query.get(scan_id)

    if not scan or scan.deleted:
        return jsonify({"error": "Not found."}), 404

    # CRITICAL IDOR protection — if the scan belongs to a DIFFERENT user → ban immediately
    # This is an Insecure Direct Object Reference attack
    if scan.user_id != current_user.id:
        _ban(current_user.id, _ip(),
             "IDOR — accessed another user's scan",
             "IDOR_ATTACK",
             f"Scan {scan_id} owned by {scan.user_id}, not {current_user.id}")
        return jsonify({"error": "Account suspended."}), 403

    scan.deleted = True  # Soft delete — data kept for audit trail
    db.session.commit()

    return jsonify({"message": "Scan deleted."}), 200
