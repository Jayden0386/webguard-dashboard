# =============================================================
#  routes/auth.py — Authentication Routes
#  FILE: webguard-backend/routes/auth.py
# =============================================================
#
#  ROUTES:
#    POST /api/auth/register       ← create new account
#    POST /api/auth/login          ← login (owner → 2FA step)
#    POST /api/auth/logout         ← clear session
#    POST /api/auth/disclaimer     ← accept ethical use terms
#    GET  /api/auth/status         ← check current session state
# =============================================================

import re
import bcrypt
from datetime import datetime, timezone, timedelta
from flask import Blueprint, request, jsonify, session, current_app
from flask_login import login_user, logout_user, login_required, current_user
from models import db, User

auth_bp = Blueprint("auth", __name__)


def _ip():
    return (
        request.headers.get("X-Forwarded-For", request.remote_addr)
        .split(",")[0].strip()
    )


# =============================================================
#  POST /api/auth/register
# =============================================================
@auth_bp.route("/api/auth/register", methods=["POST"])
def register():
    data     = request.get_json(silent=True) or {}
    email    = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))

    if not email or not password:
        return jsonify({"error": "Email and password are required."}), 400

    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        return jsonify({"error": "Invalid email format."}), 400

    # Minimum password strength: 8 chars, 1 uppercase, 1 digit
    if (len(password) < 8
            or not re.search(r"[A-Z]", password)
            or not re.search(r"\d", password)):
        return jsonify({
            "error": "Password must be 8+ chars with 1 uppercase and 1 number."
        }), 400

    if User.query.filter_by(email=email).first():
        return jsonify({"error": "Email already registered."}), 409

    # bcrypt with cost factor 12 — slow enough to resist brute force
    pw_hash = bcrypt.hashpw(
        password.encode("utf-8"),
        bcrypt.gensalt(rounds=12),
    ).decode("utf-8")

    user = User(email=email, password_hash=pw_hash, role="user")
    db.session.add(user)
    db.session.commit()

    return jsonify({"message": "Account created. Please log in."}), 201


# =============================================================
#  POST /api/auth/login
# =============================================================
@auth_bp.route("/api/auth/login", methods=["POST"])
def login():
    data     = request.get_json(silent=True) or {}
    email    = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))
    ip       = _ip()

    user = User.query.filter_by(email=email).first()

    # Same error message whether email exists or not
    # WHY: different messages allow attackers to enumerate valid emails
    BAD = {"error": "Invalid credentials."}

    if not user:
        return jsonify(BAD), 401

    if user.is_banned:
        return jsonify({"error": "Account suspended."}), 403

    if not bcrypt.checkpw(password.encode(), user.password_hash.encode()):
        user.failed_login_count += 1
        db.session.commit()
        if user.failed_login_count >= 10:
            from models import BannedUser, BannedIP, SecurityIncident
            inc = SecurityIncident(
                user_id=user.id, ip_address=ip,
                incident_type="BRUTE_FORCE_LOGIN",
                details=f"Count: {user.failed_login_count}"
            )
            db.session.add(inc)
            user.is_banned = True
            db.session.add(BannedUser(user_id=user.id, reason="10+ failed logins"))
            if not BannedIP.query.filter_by(ip_address=ip).first():
                db.session.add(BannedIP(ip_address=ip, reason="Brute force login"))
            db.session.commit()
            session.clear()
            return jsonify({"error": "Account suspended."}), 403
        return jsonify(BAD), 401

    # Password correct — reset counter
    user.failed_login_count = 0
    db.session.commit()

    # Owner: send to 2FA step — do NOT create full session yet
    if user.role == "owner":
        if user.two_fa_locked_until:
            lock = datetime.fromisoformat(user.two_fa_locked_until).replace(tzinfo=timezone.utc)
            if datetime.now(timezone.utc) < lock:
                mins = int((lock - datetime.now(timezone.utc)).total_seconds() / 60)
                return jsonify({"error": f"2FA locked. Try in {mins} min."}), 403
        session["pre_2fa_user_id"] = user.id
        return jsonify({
            "message": "Password correct. 2FA required.",
            "requires_2fa": True
        }), 200

    login_user(user, remember=False)
    session.permanent = True

    return jsonify({
        "message": "Login successful.",
        "user": {
            "id":                   user.id,
            "email":                user.email,
            "disclaimer_accepted":  user.disclaimer_accepted,
        },
    }), 200


# =============================================================
#  POST /api/auth/logout
# =============================================================
@auth_bp.route("/api/auth/logout", methods=["POST"])
def logout():
    logout_user()
    session.clear()  # Wipe ALL session keys including custom ones
    return jsonify({"message": "Logged out."}), 200


# =============================================================
#  POST /api/auth/disclaimer
# =============================================================
@auth_bp.route("/api/auth/disclaimer", methods=["POST"])
@login_required
def accept_disclaimer():
    current_user.disclaimer_accepted = True
    db.session.commit()
    return jsonify({"message": "Disclaimer accepted."}), 200


# =============================================================
#  GET /api/auth/status
# =============================================================
@auth_bp.route("/api/auth/status", methods=["GET"])
def auth_status():
    """Called on app load to restore session state in the frontend."""
    if current_user.is_authenticated:
        return jsonify({
            "authenticated":        True,
            "role":                 current_user.role,
            "disclaimer_accepted":  current_user.disclaimer_accepted,
            "email":                current_user.email,
        }), 200
    return jsonify({"authenticated": False}), 200
