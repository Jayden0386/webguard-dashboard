# =============================================================
#  routes/owner.py — Owner / Super-Admin Routes
#  FILE: webguard-backend/routes/owner.py
# =============================================================
#
#  ROUTES:
#    POST /api/owner/verify-2fa    ← complete owner login with TOTP
#    GET  /api/owner/stats         ← system overview stats
#    GET  /api/owner/users         ← all user accounts
#    GET  /api/owner/bans          ← banned accounts + IPs
#    GET  /api/owner/incidents     ← security incident log
#    POST /api/owner/lift-ban      ← lift a ban (requires fresh 2FA)
#
#  SECURITY:
#    - Every route except verify-2fa requires: login + 2FA + owner role
#    - Owner session expires after 15 minutes
#    - Owner session is bound to IP address
#    - Lift-ban requires 2FA verified within last 5 minutes
# =============================================================

import pyotp
from functools import wraps
from datetime import datetime, timedelta, timezone
from flask import Blueprint, request, jsonify, session
from flask_login import login_user, login_required, current_user
from models import db, User, ScanHistory, BannedUser, BannedIP, SecurityIncident

owner_bp = Blueprint("owner", __name__)


def _ip():
    return (
        request.headers.get("X-Forwarded-For", request.remote_addr)
        .split(",")[0].strip()
    )


# =============================================================
#  Owner 2FA Decorator
#  Checks: authenticated + owner role + 2FA verified + not expired + IP match
# =============================================================
def require_owner_2fa(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated:
            return jsonify({"error": "Authentication required."}), 401

        if current_user.role != "owner":
            # Return 404 not 403 — never confirm owner routes exist to non-owners
            return jsonify({"error": "Not found."}), 404

        if not session.get("owner_2fa_verified"):
            return jsonify({"error": "2FA verification required."}), 403

        # Owner session expires after 15 minutes
        ts = session.get("owner_2fa_verified_at")
        if ts:
            dt = datetime.fromisoformat(ts)
            if datetime.now(timezone.utc) - dt > timedelta(minutes=15):
                session.pop("owner_2fa_verified", None)
                return jsonify({"error": "Owner session expired. Re-verify 2FA."}), 403

        # Session is bound to IP — if IP changes mid-session → logout immediately
        if session.get("owner_session_ip") != _ip():
            session.clear()
            return jsonify({"error": "Session IP mismatch. Log in again."}), 403

        return f(*args, **kwargs)
    return decorated


# =============================================================
#  POST /api/owner/verify-2fa
#  Complete owner login by verifying TOTP code
# =============================================================
@owner_bp.route("/api/owner/verify-2fa", methods=["POST"])
def owner_verify_2fa():
    pre_id = session.get("pre_2fa_user_id")
    if not pre_id:
        return jsonify({"error": "No pending 2FA session."}), 400

    data = request.get_json(silent=True) or {}
    code = str(data.get("code", "")).strip()
    user = User.query.get(pre_id)

    if not user or user.role != "owner":
        return jsonify({"error": "Invalid session."}), 401

    # Check 2FA lockout
    if user.two_fa_locked_until:
        lock = datetime.fromisoformat(user.two_fa_locked_until).replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) < lock:
            mins = int((lock - datetime.now(timezone.utc)).total_seconds() / 60)
            return jsonify({"error": f"2FA locked for {mins} more minutes."}), 403

    # valid_window=1 → allows ±30 seconds for clock drift between server and phone
    totp = pyotp.TOTP(user.totp_secret)
    if not totp.verify(code, valid_window=1):
        user.failed_2fa_count += 1
        db.session.commit()

        # Lock for 1 hour after 3 wrong attempts
        if user.failed_2fa_count >= 3:
            lock_until = datetime.now(timezone.utc) + timedelta(hours=1)
            user.two_fa_locked_until = lock_until.isoformat()
            user.failed_2fa_count = 0
            db.session.commit()

            # Log the incident
            inc = SecurityIncident(
                user_id=user.id, ip_address=_ip(),
                incident_type="OWNER_2FA_LOCKOUT",
                details="3 failed 2FA attempts — owner account locked for 1 hour"
            )
            db.session.add(inc)
            db.session.commit()

            return jsonify({"error": "2FA locked for 1 hour."}), 403

        return jsonify({"error": "Invalid 2FA code."}), 401

    # Success — reset counters and create full owner session
    user.failed_2fa_count    = 0
    user.two_fa_locked_until = None
    db.session.commit()

    session.pop("pre_2fa_user_id", None)
    login_user(user, remember=False)
    session.permanent = True
    session["owner_2fa_verified"]    = True
    session["owner_2fa_verified_at"] = datetime.now(timezone.utc).isoformat()
    session["owner_session_ip"]      = _ip()   # Bind session to current IP

    return jsonify({"message": "2FA verified. Owner session active."}), 200


# =============================================================
#  GET /api/owner/stats
# =============================================================
@owner_bp.route("/api/owner/stats", methods=["GET"])
@login_required
@require_owner_2fa
def owner_stats():
    return jsonify({
        "total_users":        User.query.filter_by(role="user").count(),
        "total_scans":        ScanHistory.query.filter_by(deleted=False).count(),
        "banned_users":       BannedUser.query.count(),
        "banned_ips":         BannedIP.query.count(),
        "security_incidents": SecurityIncident.query.count(),
    }), 200


# =============================================================
#  GET /api/owner/users
# =============================================================
@owner_bp.route("/api/owner/users", methods=["GET"])
@login_required
@require_owner_2fa
def owner_users():
    users = User.query.all()
    return jsonify({"users": [
        {
            "id":                  u.id,
            "email":               u.email,
            "role":                u.role,
            "is_banned":           u.is_banned,
            "disclaimer_accepted": u.disclaimer_accepted,
            "created_at":          u.created_at.isoformat(),
        }
        for u in users
    ]}), 200


# =============================================================
#  GET /api/owner/bans
# =============================================================
@owner_bp.route("/api/owner/bans", methods=["GET"])
@login_required
@require_owner_2fa
def owner_bans():
    return jsonify({
        "banned_users": [
            {
                "user_id":   b.user_id,
                "reason":    b.reason,
                "banned_at": b.banned_at.isoformat(),
            }
            for b in BannedUser.query.all()
        ],
        "banned_ips": [
            {
                "ip":        b.ip_address,
                "reason":    b.reason,
                "banned_at": b.banned_at.isoformat(),
            }
            for b in BannedIP.query.all()
        ],
    }), 200


# =============================================================
#  GET /api/owner/incidents
# =============================================================
@owner_bp.route("/api/owner/incidents", methods=["GET"])
@login_required
@require_owner_2fa
def owner_incidents():
    rows = (
        SecurityIncident.query
        .order_by(SecurityIncident.occurred_at.desc())
        .limit(100)
        .all()
    )
    return jsonify({"incidents": [
        {
            "id":          i.id,
            "user_id":     i.user_id,
            "ip":          i.ip_address,
            "type":        i.incident_type,
            "details":     i.details,
            "occurred_at": i.occurred_at.isoformat(),
        }
        for i in rows
    ]}), 200


# =============================================================
#  POST /api/owner/lift-ban
#  Requires 2FA verified within the last 5 minutes
# =============================================================
@owner_bp.route("/api/owner/lift-ban", methods=["POST"])
@login_required
@require_owner_2fa
def owner_lift_ban():
    # Extra security: must have verified 2FA within last 5 minutes
    # This forces re-verification for sensitive destructive actions
    ts = session.get("owner_2fa_verified_at")
    if not ts:
        return jsonify({"error": "2FA required."}), 403

    if datetime.now(timezone.utc) - datetime.fromisoformat(ts) > timedelta(minutes=5):
        return jsonify({"error": "Re-verify 2FA to perform this action."}), 403

    data       = request.get_json(silent=True) or {}
    user_id    = data.get("user_id")
    ip_address = data.get("ip_address")

    if user_id:
        u = User.query.get(user_id)
        if u:
            u.is_banned = False
            BannedUser.query.filter_by(user_id=user_id).delete()
            db.session.commit()

    if ip_address:
        BannedIP.query.filter_by(ip_address=ip_address).delete()
        db.session.commit()

    return jsonify({"message": "Ban lifted."}), 200
