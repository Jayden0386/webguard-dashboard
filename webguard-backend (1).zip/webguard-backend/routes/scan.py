# =============================================================
#  routes/scan.py — Scan Route
#  FILE: webguard-backend/routes/scan.py
# =============================================================
#
#  ROUTES:
#    POST /api/scan  ← run surface + deep + hacker intel scan
#
#  SECURITY:
#    - Login required
#    - Disclaimer must be accepted
#    - Rate limited: 5 scans per hour
#    - SSRF protection: internal IPs blocked
# =============================================================

import re
import json
from datetime import datetime
from urllib.parse import urlparse
from flask import Blueprint, request, jsonify, session, current_app
from flask_login import login_required, current_user
from models import db, ScanHistory, BannedUser, BannedIP, SecurityIncident
from security import get_fernet, is_ssrf_target
from scanner.checks import run_surface_scan
from scanner.deep_checks import run_deep_scan
from scanner.hacker_intel import run_hacker_intel_scan

scan_bp = Blueprint("scan", __name__)


def _ip():
    return (
        request.headers.get("X-Forwarded-For", request.remote_addr)
        .split(",")[0].strip()
    )


def _ban(user_id, ip, reason, incident_type, details):
    """Permanently ban a user and IP."""
    inc = SecurityIncident(
        user_id=user_id, ip_address=ip,
        incident_type=incident_type, details=details,
    )
    db.session.add(inc)
    if user_id:
        u = db.session.get(type(current_user), user_id)
        if u and not u.is_banned:
            u.is_banned = True
            db.session.add(BannedUser(user_id=user_id, reason=reason))
    if not BannedIP.query.filter_by(ip_address=ip).first():
        db.session.add(BannedIP(ip_address=ip, reason=reason))
    db.session.commit()
    session.clear()


# =============================================================
#  POST /api/scan
# =============================================================
@scan_bp.route("/api/scan", methods=["POST"])
@login_required
def run_scan():
    # Must accept disclaimer before scanning
    if not current_user.disclaimer_accepted:
        return jsonify({
            "error": "You must accept the ethical use disclaimer before scanning."
        }), 403

    data   = request.get_json(silent=True) or {}
    target = str(data.get("url", "")).strip()

    if not target:
        return jsonify({"error": "URL is required."}), 400

    if not re.match(r"^https?://", target, re.I):
        return jsonify({"error": "URL must start with http:// or https://"}), 400

    # SSRF protection — block scans targeting internal/private network
    hostname = urlparse(target).hostname or ""
    if is_ssrf_target(hostname):
        _ban(current_user.id, _ip(),
             "SSRF scan attempt", "SSRF_ATTEMPT",
             f"Target: {target}")
        return jsonify({"error": "Account suspended."}), 403

    # Run all three scan modules
    surface      = run_surface_scan(target)
    deep         = run_deep_scan(target)
    hacker_intel = run_hacker_intel_scan(target)

    # Combine findings and calculate final score
    all_findings = surface.get("findings", []) + deep.get("findings", [])
    final_score  = max(0, surface.get("score", 100) - deep.get("score_deduction", 0))

    result = {
        "url":          target,
        "scan_date":    datetime.utcnow().isoformat(),
        "surface":      surface,
        "deep":         deep,
        "hacker_intel": hacker_intel,
        "all_findings": all_findings,
        "final_score":  final_score,
    }

    # Encrypt before storing — AES-128-CBC + HMAC via Fernet
    encrypted = get_fernet().encrypt(json.dumps(result).encode()).decode()

    record = ScanHistory(
        user_id=current_user.id,
        target_url=target,
        encrypted_result=encrypted,
    )
    db.session.add(record)
    db.session.commit()

    return jsonify({"scan_id": record.id, "result": result}), 200
