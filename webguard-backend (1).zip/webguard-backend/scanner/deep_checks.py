# =============================================================
#  scanner/deep_checks.py — Deep / Hidden Scan Functions
#  FILE: webguard-backend/scanner/deep_checks.py
# =============================================================
#
#  DEEP SCAN = probing beyond the homepage with targeted requests.
#  Checks: sensitive files, admin panels, JS secrets, TLS, subdomains.
#
#  ETHICAL REMINDER: Only scan with explicit permission.
# =============================================================

import re
import ssl
import socket
import requests
from bs4 import BeautifulSoup
from datetime import datetime, timezone
from urllib.parse import urlparse

REQUEST_TIMEOUT = 10
BROWSER_UA = {"User-Agent": "Mozilla/5.0 (WebGuard Security Scanner / Authorized)"}


def _get(url: str):
    """Safe HTTP GET — returns Response or None on any error."""
    try:
        return requests.get(
            url, timeout=REQUEST_TIMEOUT, headers=BROWSER_UA,
            verify=True, allow_redirects=False,
        )
    except Exception:
        return None


def run_deep_scan(url: str) -> dict:
    """
    Run all deep/hidden checks on a URL.
    Returns: { findings: [...], score_deduction: int, checks_run: int }
    score_deduction is subtracted from the surface scan score.
    """
    findings        = []
    score_deduction = 0
    parsed          = urlparse(url)
    base            = f"{parsed.scheme}://{parsed.netloc}"

    # ----------------------------------------------------------
    #  CHECK 1 — Exposed Sensitive Files
    # ----------------------------------------------------------
    sensitive_files = [
        ("/.env",          "CRITICAL", ".env file is publicly accessible — all secrets exposed!"),
        ("/.git/config",   "CRITICAL", "Git repository config exposed — source code may be leaked."),
        ("/backup.zip",    "HIGH",     "Backup archive is publicly downloadable."),
        ("/phpinfo.php",   "HIGH",     "phpinfo() page exposes full server configuration."),
        ("/config.php",    "HIGH",     "config.php accessible — may contain DB credentials."),
        ("/wp-config.php", "CRITICAL", "WordPress config exposed — contains DB credentials."),
        ("/web.config",    "HIGH",     "IIS web.config exposed — may leak sensitive settings."),
        ("/.DS_Store",     "LOW",      ".DS_Store exposes directory structure (Mac server)."),
    ]
    for path, severity, message in sensitive_files:
        resp = _get(base + path)
        if resp and resp.status_code == 200:
            findings.append({
                "type": "EXPOSED_FILE", "severity": severity,
                "message": message, "path": path,
            })
            score_deduction += 20 if severity == "CRITICAL" else 12

    # ----------------------------------------------------------
    #  CHECK 2 — Hidden Admin Panels
    # ----------------------------------------------------------
    for path in ["/admin", "/wp-admin", "/dashboard", "/panel",
                 "/administrator", "/controlpanel", "/manage", "/backend"]:
        resp = _get(base + path)
        if resp and resp.status_code in (200, 301, 302, 403):
            findings.append({
                "type": "ADMIN_PANEL_EXPOSED", "severity": "HIGH",
                "message": f"Admin panel accessible at: {path} (HTTP {resp.status_code})",
                "detail": "Restrict admin URLs to specific IPs or put them behind a VPN.",
                "path": path,
            })
            score_deduction += 15

    # ----------------------------------------------------------
    #  CHECK 3 — HTML Source: Leaked Credentials & Internal IPs
    # ----------------------------------------------------------
    try:
        resp = _get(url)
        if resp and resp.status_code == 200:
            soup       = BeautifulSoup(resp.text, "html.parser")
            secret_re  = re.compile(
                r"(password|passwd|secret|api[_\-]?key|token|auth|bearer|private[_\-]?key)",
                re.IGNORECASE,
            )
            for item in soup.find_all(string=True):
                if "<!--" in str(item) and secret_re.search(str(item)):
                    findings.append({
                        "type": "LEAKED_SECRET_HTML", "severity": "CRITICAL",
                        "message": "Possible credential or API key found in an HTML comment.",
                        "detail": "Remove ALL secrets from HTML source immediately.",
                    })
                    score_deduction += 25
                    break

            internal_ips = re.findall(
                r"\b(192\.168\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|"
                r"172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3})\b",
                resp.text,
            )
            if internal_ips:
                findings.append({
                    "type": "INTERNAL_IP_DISCLOSED", "severity": "MEDIUM",
                    "message": f"Internal IP(s) found in page source: {list(set(internal_ips))[:3]}",
                    "detail": "Remove internal network addresses from all public-facing pages.",
                })
                score_deduction += 10
    except Exception:
        pass

    # ----------------------------------------------------------
    #  CHECK 4 — JavaScript Files: Hardcoded Secrets
    # ----------------------------------------------------------
    try:
        resp = _get(url)
        if resp and resp.status_code == 200:
            soup          = BeautifulSoup(resp.text, "html.parser")
            js_secret_re  = re.compile(
                r"(api[_\-]?key|apikey|secret|token|password|auth|bearer|private_key)"
                r"\s*[:=]\s*['\"][a-zA-Z0-9_\-\.]{8,}['\"]",
                re.IGNORECASE,
            )
            for tag in soup.find_all("script", src=True)[:5]:
                js_url = tag["src"]
                if not js_url.startswith("http"):
                    js_url = base + (js_url if js_url.startswith("/") else "/" + js_url)
                js_resp = _get(js_url)
                if js_resp and js_resp.status_code == 200 and js_secret_re.search(js_resp.text):
                    findings.append({
                        "type": "HARDCODED_SECRET_JS", "severity": "CRITICAL",
                        "message": f"Possible hardcoded secret in JS file: {js_url}",
                        "detail": "Move all secrets to server-side environment variables.",
                    })
                    score_deduction += 25
                    break
    except Exception:
        pass

    # ----------------------------------------------------------
    #  CHECK 5 — Robots.txt Hidden Path Disclosure
    # ----------------------------------------------------------
    robots_resp = _get(base + "/robots.txt")
    if robots_resp and robots_resp.status_code == 200:
        disallowed = re.findall(r"Disallow:\s*(.+)", robots_resp.text)
        flagged = [
            p.strip() for p in disallowed
            if re.search(r"admin|backup|config|secret|private|internal|db", p, re.I)
        ]
        if flagged:
            findings.append({
                "type": "ROBOTS_SENSITIVE_PATHS", "severity": "INFO",
                "message": f"robots.txt reveals sensitive-looking paths: {flagged[:5]}",
                "detail": "Don't list sensitive paths in robots.txt — use proper authentication.",
            })
            score_deduction += 5

    # ----------------------------------------------------------
    #  CHECK 6 — Directory Listing Detection
    # ----------------------------------------------------------
    for path in ["/images/", "/uploads/", "/assets/", "/files/", "/static/"]:
        resp = _get(base + path)
        if resp and resp.status_code == 200:
            if "Index of /" in resp.text or "Directory listing" in resp.text:
                findings.append({
                    "type": "DIRECTORY_LISTING", "severity": "MEDIUM",
                    "message": f"Directory listing enabled at: {path}",
                    "detail": "Disable directory indexing in your web server config.",
                })
                score_deduction += 10

    # ----------------------------------------------------------
    #  CHECK 7 — Verbose Error / Stack Trace Detection
    # ----------------------------------------------------------
    err_resp = _get(base + "/trigger-404-webguard-probe")
    if err_resp:
        stack_re = re.compile(
            r"(Traceback \(most recent call last\)|at line \d+|stack trace|"
            r"SQLException|NullPointerException|undefined variable|"
            r"Warning: .* on line \d+)",
            re.IGNORECASE,
        )
        if stack_re.search(err_resp.text):
            findings.append({
                "type": "VERBOSE_ERRORS", "severity": "HIGH",
                "message": "Server returns verbose error messages or stack traces.",
                "detail": "Disable debug mode and configure custom error pages for production.",
            })
            score_deduction += 15

    # ----------------------------------------------------------
    #  CHECK 8 — Subdomain Enumeration
    # ----------------------------------------------------------
    domain     = parsed.netloc.replace("www.", "")
    found_subs = []
    for sub in ["admin", "api", "dev", "staging", "test", "beta", "internal"]:
        resp = _get(f"{parsed.scheme}://{sub}.{domain}")
        if resp and resp.status_code in (200, 301, 302, 403):
            found_subs.append(f"{sub}.{domain}")
    if found_subs:
        findings.append({
            "type": "SUBDOMAINS_FOUND", "severity": "INFO",
            "message": f"Active subdomains discovered: {found_subs}",
            "detail": "Ensure all subdomains apply the same security standards as the main site.",
        })
        score_deduction += 5

    # ----------------------------------------------------------
    #  CHECK 9 — Outdated JavaScript Libraries
    # ----------------------------------------------------------
    try:
        resp = _get(url)
        if resp and resp.status_code == 200:
            outdated = {
                "jQuery 1.x":    re.compile(r"jquery[/-]1\.\d+", re.I),
                "jQuery 2.x":    re.compile(r"jquery[/-]2\.\d+", re.I),
                "Bootstrap 3.x": re.compile(r"bootstrap[/-]3\.\d+", re.I),
                "AngularJS 1.x": re.compile(r"angular[/-]1\.\d+", re.I),
            }
            for lib, pat in outdated.items():
                if pat.search(resp.text):
                    findings.append({
                        "type": "OUTDATED_JS_LIBRARY", "severity": "MEDIUM",
                        "message": f"Outdated library detected: {lib}",
                        "detail": "Update to the latest stable version to fix known CVEs.",
                    })
                    score_deduction += 8
    except Exception:
        pass

    # ----------------------------------------------------------
    #  CHECK 10 — TLS Certificate Expiry
    # ----------------------------------------------------------
    if parsed.scheme == "https":
        try:
            ctx  = ssl.create_default_context()
            conn = ctx.wrap_socket(socket.socket(), server_hostname=parsed.netloc)
            conn.settimeout(5)
            conn.connect((parsed.netloc, 443))
            cert = conn.getpeercert()
            conn.close()

            expires_str = cert.get("notAfter", "")
            if expires_str:
                expires   = datetime.strptime(expires_str, "%b %d %H:%M:%S %Y %Z")
                expires   = expires.replace(tzinfo=timezone.utc)
                days_left = (expires - datetime.now(timezone.utc)).days

                if days_left < 0:
                    findings.append({
                        "type": "TLS_CERT_EXPIRED", "severity": "CRITICAL",
                        "message": "TLS certificate is EXPIRED. HTTPS is broken.",
                        "detail": "Renew immediately. Users will see browser security warnings.",
                    })
                    score_deduction += 30
                elif days_left < 30:
                    findings.append({
                        "type": "TLS_CERT_EXPIRING", "severity": "HIGH",
                        "message": f"TLS certificate expires in {days_left} days.",
                        "detail": "Renew before it expires to avoid downtime.",
                    })
                    score_deduction += 10

        except ssl.SSLError as e:
            findings.append({
                "type": "TLS_SSL_ERROR", "severity": "HIGH",
                "message": f"TLS configuration error: {str(e)[:80]}",
                "detail": "Review your SSL/TLS server settings.",
            })
            score_deduction += 15
        except Exception:
            pass

    # ----------------------------------------------------------
    #  CHECK 11 — GDPR / Privacy Compliance Basics
    # ----------------------------------------------------------
    try:
        resp = _get(url)
        if resp and resp.status_code == 200:
            text = resp.text.lower()
            if "cookie" not in text and "consent" not in text:
                findings.append({
                    "type": "NO_COOKIE_CONSENT", "severity": "INFO",
                    "message": "No cookie consent banner detected.",
                    "detail": "GDPR requires informing EU users about cookie usage.",
                })
            if "privacy policy" not in text and "privacy-policy" not in text:
                findings.append({
                    "type": "NO_PRIVACY_POLICY", "severity": "INFO",
                    "message": "No privacy policy link found.",
                    "detail": "Most jurisdictions require a publicly accessible privacy policy.",
                })
            for tracker in ["google-analytics.com", "facebook.net/en_US/fbevents", "hotjar.com"]:
                if tracker in resp.text:
                    findings.append({
                        "type": "THIRD_PARTY_TRACKERS", "severity": "INFO",
                        "message": f"Third-party tracker found: {tracker}",
                        "detail": "Disclose all trackers in your privacy policy and consent banner.",
                    })
    except Exception:
        pass

    # ----------------------------------------------------------
    #  CHECK 12 — CMS Fingerprinting
    # ----------------------------------------------------------
    cms_sigs = {
        "WordPress": ["/wp-content/", "/wp-includes/", "wp-json"],
        "Joomla":    ["/components/com_", "Joomla!"],
        "Drupal":    ["/sites/default/files", "Drupal.settings"],
    }
    try:
        resp = _get(url)
        if resp and resp.status_code == 200:
            for cms, patterns in cms_sigs.items():
                if any(p in resp.text for p in patterns):
                    findings.append({
                        "type": "CMS_DETECTED", "severity": "INFO",
                        "message": f"CMS fingerprinted: {cms}",
                        "detail": f"Keep {cms} core, themes, and plugins fully updated.",
                    })
                    score_deduction += 3
                    break
    except Exception:
        pass

    return {
        "findings":        findings,
        "score_deduction": score_deduction,
        "checks_run":      12,
    }
