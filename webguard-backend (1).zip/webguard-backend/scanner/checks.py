# =============================================================
#  scanner/checks.py — Surface Scan Functions
#  FILE: webguard-backend/scanner/checks.py
# =============================================================
#
#  SURFACE SCAN = visible issues found in a single HTTP request.
#  We inspect:
#    - Response headers (security headers missing?)
#    - Cookies (missing Secure/HttpOnly/SameSite flags?)
#    - HTML body (risky inline scripts, unprotected forms?)
#    - URL structure (SQL injection parameter hints?)
#
#  ETHICAL REMINDER: Only scan sites you own or have written
#  permission to test. Unauthorized scanning is illegal.
# =============================================================

import re
import requests
from bs4 import BeautifulSoup

REQUEST_TIMEOUT = 10
BROWSER_UA = {"User-Agent": "Mozilla/5.0 (WebGuard Security Scanner / Authorized)"}

REQUIRED_SECURITY_HEADERS = [
    "Content-Security-Policy",
    "Strict-Transport-Security",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
    "Permissions-Policy",
]


def run_surface_scan(url: str) -> dict:
    """
    Run all surface-level checks on a URL.
    Returns: { findings: [...], score: 0-100, checks_run: int }
    Higher score = more secure.
    """
    findings = []
    score    = 100  # Start perfect, deduct for each problem

    try:
        response = requests.get(
            url, timeout=REQUEST_TIMEOUT,
            allow_redirects=True,
            headers=BROWSER_UA,
            verify=True,
        )
    except requests.exceptions.SSLError:
        findings.append({
            "type": "SSL_ERROR", "severity": "CRITICAL",
            "message": "TLS/SSL certificate error — HTTPS connection failed.",
            "detail": "Obtain a valid certificate from a trusted CA (e.g. Let's Encrypt).",
        })
        return {"findings": findings, "score": 0, "error": "ssl_error"}
    except requests.exceptions.ConnectionError:
        return {"findings": [], "score": 0, "error": "connection_failed"}
    except requests.exceptions.Timeout:
        return {"findings": [], "score": 0, "error": "timeout"}
    except Exception:
        return {"findings": [], "score": 0, "error": "request_failed"}

    headers = response.headers

    # ----------------------------------------------------------
    #  CHECK 1 — Missing Security Headers
    # ----------------------------------------------------------
    for header in REQUIRED_SECURITY_HEADERS:
        if header not in headers:
            findings.append({
                "type": "MISSING_HEADER", "severity": "MEDIUM",
                "message": f"Missing security header: {header}",
                "detail": f"Add the '{header}' header to all HTTP responses.",
            })
            score -= 5

    # ----------------------------------------------------------
    #  CHECK 2 — HTTP instead of HTTPS
    # ----------------------------------------------------------
    if response.url.startswith("http://"):
        findings.append({
            "type": "NO_HTTPS", "severity": "HIGH",
            "message": "Site is not using HTTPS. All traffic sent in plaintext.",
            "detail": "Get a free TLS cert from Let's Encrypt and redirect all HTTP to HTTPS.",
        })
        score -= 20

    # ----------------------------------------------------------
    #  CHECK 3 — Server / Framework Version Disclosure
    #  "Server: Apache/2.4.51" tells attackers which CVEs apply
    # ----------------------------------------------------------
    server    = headers.get("Server", "")
    x_powered = headers.get("X-Powered-By", "")

    if server:
        findings.append({
            "type": "SERVER_DISCLOSURE", "severity": "LOW",
            "message": f"Server header reveals software: '{server}'",
            "detail": "Configure your server to hide or genericize the Server header.",
        })
        score -= 5

    if x_powered:
        findings.append({
            "type": "FRAMEWORK_DISCLOSURE", "severity": "LOW",
            "message": f"X-Powered-By exposes tech stack: '{x_powered}'",
            "detail": "Remove the X-Powered-By header entirely.",
        })
        score -= 5

    # ----------------------------------------------------------
    #  CHECK 4 — Insecure Cookie Flags
    # ----------------------------------------------------------
    set_cookie = headers.get("Set-Cookie", "")
    if set_cookie:
        if "Secure" not in set_cookie:
            findings.append({
                "type": "COOKIE_NO_SECURE", "severity": "MEDIUM",
                "message": "Cookie missing 'Secure' flag — can be sent over HTTP.",
                "detail": "Add 'Secure' so cookies only travel over HTTPS.",
            })
            score -= 8

        if "HttpOnly" not in set_cookie:
            findings.append({
                "type": "COOKIE_NO_HTTPONLY", "severity": "MEDIUM",
                "message": "Cookie missing 'HttpOnly' — JavaScript can read it.",
                "detail": "Add 'HttpOnly' to prevent XSS from stealing cookies.",
            })
            score -= 8

        if "SameSite" not in set_cookie:
            findings.append({
                "type": "COOKIE_NO_SAMESITE", "severity": "LOW",
                "message": "Cookie missing 'SameSite' attribute — CSRF risk.",
                "detail": "Add 'SameSite=Strict' or 'SameSite=Lax' to prevent CSRF.",
            })
            score -= 4

    # ----------------------------------------------------------
    #  CHECK 5 — XSS Indicators in HTML
    # ----------------------------------------------------------
    try:
        soup = BeautifulSoup(response.text, "html.parser")

        # Inline event handlers like onclick="..." are XSS hotspots
        risky = soup.find_all(
            True,
            attrs=lambda a: a and any(k.startswith("on") for k in a.keys()),
        )
        if risky:
            findings.append({
                "type": "XSS_INLINE_HANDLERS", "severity": "MEDIUM",
                "message": f"Found {len(risky)} inline event handler(s) (onclick, onload, etc.)",
                "detail": "Move handlers to external JS. Use CSP to block inline scripts.",
            })
            score -= 8

        # Forms without CSRF tokens are vulnerable to CSRF attacks
        forms       = soup.find_all("form")
        unprotected = sum(
            1 for f in forms
            if not f.find("input", attrs={"name": re.compile(r"csrf|token|_token", re.I)})
        )
        if unprotected:
            findings.append({
                "type": "CSRF_NO_TOKEN", "severity": "HIGH",
                "message": f"{unprotected} form(s) found without a CSRF token.",
                "detail": "Add anti-CSRF tokens to all state-changing forms.",
            })
            score -= 10

    except Exception:
        pass

    # ----------------------------------------------------------
    #  CHECK 6 — SQL Injection Hints in URL Parameters
    # ----------------------------------------------------------
    risky_params = re.compile(
        r"[?&](id|user|username|name|search|query|q|page|cat|item|product)=",
        re.IGNORECASE,
    )
    if risky_params.search(url):
        findings.append({
            "type": "SQLI_HINT_URL", "severity": "INFO",
            "message": "URL contains parameter names commonly targeted in SQL injection.",
            "detail": "Verify all DB queries use parameterized statements, not string formatting.",
        })
        score -= 3

    # ----------------------------------------------------------
    #  CHECK 7 — Open Redirect Links
    # ----------------------------------------------------------
    if re.search(
        r'href=["\'].*?(redirect|return|next|url|goto|target)=https?://',
        response.text, re.IGNORECASE
    ):
        findings.append({
            "type": "OPEN_REDIRECT", "severity": "MEDIUM",
            "message": "Possible open redirect link found in page source.",
            "detail": "Validate all redirect targets against a whitelist of allowed domains.",
        })
        score -= 8

    return {
        "findings":    findings,
        "score":       max(0, min(100, score)),
        "checks_run":  7,
        "http_status": response.status_code,
        "final_url":   response.url,
    }
