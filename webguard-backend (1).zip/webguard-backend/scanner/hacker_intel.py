# =============================================================
#  scanner/hacker_intel.py — Hacker Tool Intelligence Engine
#  FILE: webguard-backend/scanner/hacker_intel.py
# =============================================================
#
#  Simulates what 8 major hacking tools would find on a site.
#  ALL checks are PASSIVE and READ-ONLY — no actual attacks.
#
#  Each finding shows:
#    - tool:             which tool would find this
#    - what_hacker_sees: exactly what an attacker discovers
#    - how_tool_attacks: how the tool exploits it
#    - alert:            plain English warning to site owner
#    - fix:              exact steps to fix it
#
#  Tools simulated:
#    1. Nmap       — port/service fingerprinting
#    2. Nikto      — dangerous files and misconfigurations
#    3. SQLMap     — SQL injection detection
#    4. Burp Suite — session, CSRF, IDOR vulnerabilities
#    5. OWASP ZAP  — full OWASP Top 10 check
#    6. Acunetix   — deep crawl and LFI detection
#    7. Nessus     — TLS/SSL and CVE analysis
#    8. OpenVAS    — CORS and configuration audit
#
#  ETHICAL NOTICE: This module checks for SIGNS of vulnerability,
#  not actual exploitation. Only scan with permission.
# =============================================================

import re
import ssl
import socket
import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse

REQUEST_TIMEOUT = 8
BROWSER_UA = {"User-Agent": "Mozilla/5.0 (WebGuard Security Scanner / Authorized)"}


def _get(url: str):
    """Safe HTTP GET — returns Response or None."""
    try:
        return requests.get(
            url, timeout=REQUEST_TIMEOUT, headers=BROWSER_UA,
            verify=True, allow_redirects=False,
        )
    except Exception:
        return None


def run_hacker_intel_scan(url: str) -> list:
    """
    Simulate what 8 major hacking tools would find.
    Returns list of findings with full tool attribution.
    """
    findings = []
    parsed   = urlparse(url)
    base     = f"{parsed.scheme}://{parsed.netloc}"

    try:
        response = _get(url)
        if not response:
            return []
        headers = dict(response.headers)
        html    = response.text
        soup    = BeautifulSoup(html, "html.parser")
    except Exception:
        return []

    # ==============================================================
    #  1. NMAP — Port/Service Fingerprinting
    # ==============================================================
    server    = headers.get("Server", "")
    x_powered = headers.get("X-Powered-By", "")

    if server or x_powered:
        tech = server or x_powered
        findings.append({
            "tool":             "Nmap",
            "tool_description": "Network scanner that maps open ports and identifies running services",
            "category":         "Service Fingerprinting",
            "name":             "Server software version exposed in HTTP headers",
            "severity":         "high",
            "what_hacker_sees": f"Nmap would identify your exact server software: '{tech}' and instantly search CVE databases for exploits targeting that version.",
            "how_tool_attacks": "Nmap sends specially crafted packets and reads response banners to identify software. With the version known, it runs NSE scripts to find matching CVEs automatically.",
            "alert":            f"Your server is advertising '{tech}' to every visitor including attackers. A hacker can look up exploits for that exact version in under 60 seconds.",
            "fix":              "Suppress or replace the Server and X-Powered-By headers. Update your server software to the latest stable version.",
        })

    # Probe common dangerous ports
    dangerous_ports = {
        21: "FTP", 23: "Telnet", 3306: "MySQL",
        5432: "PostgreSQL", 27017: "MongoDB",
        6379: "Redis", 9200: "Elasticsearch",
    }
    for port, service in dangerous_ports.items():
        try:
            sock = socket.socket()
            sock.settimeout(1)
            if sock.connect_ex((parsed.netloc, port)) == 0:
                findings.append({
                    "tool":             "Nmap",
                    "tool_description": "Network scanner that maps open ports",
                    "category":         "Open Port Detection",
                    "name":             f"Port {port} ({service}) is open and accessible",
                    "severity":         "critical",
                    "what_hacker_sees": f"Nmap would flag port {port} ({service}) as open. This service should never be publicly accessible.",
                    "how_tool_attacks": f"Nmap scans all 65535 ports. Finding {service} exposed publicly allows direct database/service attacks without needing web access.",
                    "alert":            f"{service} on port {port} is exposed to the internet. Attackers can attempt direct login, brute force, or exploit known {service} vulnerabilities.",
                    "fix":              f"Close port {port} in your firewall immediately. {service} should only be accessible from your private network or via VPN.",
                })
            sock.close()
        except Exception:
            pass

    # ==============================================================
    #  2. NIKTO — Dangerous Files and Misconfigurations
    # ==============================================================
    nikto_files = [
        ("/phpinfo.php",    "phpinfo() reveals your entire server configuration"),
        ("/test.php",       "Test file left on production server"),
        ("/install.php",    "Installation script accessible on live server"),
        ("/setup.php",      "Setup script accessible on live server"),
        ("/.htaccess",      ".htaccess readable — reveals server rules and paths"),
        ("/README.md",      "README reveals software version and project structure"),
        ("/CHANGELOG.txt",  "Changelog reveals exact software version for CVE matching"),
    ]
    for path, description in nikto_files:
        resp = _get(base + path)
        if resp and resp.status_code == 200:
            findings.append({
                "tool":             "Nikto",
                "tool_description": "Web server scanner that finds dangerous files and misconfigurations",
                "category":         "Dangerous File Exposure",
                "name":             f"Sensitive file accessible: {path}",
                "severity":         "high",
                "what_hacker_sees": f"Nikto would flag {path} as publicly accessible. {description}.",
                "how_tool_attacks": "Nikto checks thousands of known risky file paths automatically. Finding these files gives attackers server intelligence instantly.",
                "alert":            f"The file '{path}' is publicly accessible. {description}. This is one of the first things Nikto checks.",
                "fix":              f"Remove or restrict access to {path}. It should never be accessible on a production server.",
            })

    # Dangerous HTTP methods via OPTIONS
    try:
        options_resp = requests.options(url, timeout=5, headers=BROWSER_UA, verify=True)
        allow = options_resp.headers.get("Allow", "")
        dangerous = [m for m in ["PUT", "DELETE", "TRACE", "CONNECT"] if m in allow]
        if dangerous:
            findings.append({
                "tool":             "Nikto",
                "tool_description": "Web server scanner",
                "category":         "Dangerous HTTP Methods",
                "name":             f"Dangerous HTTP methods enabled: {', '.join(dangerous)}",
                "severity":         "critical",
                "what_hacker_sees": f"Nikto detected {', '.join(dangerous)} methods are allowed. PUT allows uploading files, TRACE enables XST attacks.",
                "how_tool_attacks": "Nikto sends an OPTIONS request to list allowed methods. PUT access means an attacker can upload malicious files directly to your server.",
                "alert":            f"Your server allows {', '.join(dangerous)} HTTP methods. This could allow attackers to upload backdoors or execute cross-site tracing attacks.",
                "fix":              f"Disable {', '.join(dangerous)} methods in your web server config. Only GET and POST should be enabled for most web apps.",
            })
    except Exception:
        pass

    # ==============================================================
    #  3. SQLMAP — SQL Injection Detection
    # ==============================================================
    if parsed.query:
        params = [p.split("=")[0] for p in parsed.query.split("&") if "=" in p]
        if params:
            findings.append({
                "tool":             "SQLMap",
                "tool_description": "Automatic SQL injection detection and exploitation tool",
                "category":         "SQL Injection Risk",
                "name":             f"URL parameters detected: {', '.join(params)} — SQLMap target",
                "severity":         "high",
                "what_hacker_sees": f"SQLMap would immediately target: {', '.join(params)}. It tests dozens of injection payloads automatically.",
                "how_tool_attacks": "SQLMap sends crafted payloads like ?id=1' OR '1'='1 and measures response differences. It can dump entire databases in minutes.",
                "alert":            f"Your URL parameters ({', '.join(params)}) are prime SQLMap targets. If not using parameterized queries, your database is at risk.",
                "fix":              "Use parameterized queries (prepared statements) for ALL database operations. Never concatenate user input into SQL strings.",
            })

    # SQL error messages in response
    sql_errors = ["mysql_fetch", "ORA-", "syntax error", "Microsoft OLE DB",
                  "PostgreSQL ERROR", "sqlite3.OperationalError", "SQLSTATE"]
    for error in sql_errors:
        if error.lower() in html.lower():
            findings.append({
                "tool":             "SQLMap",
                "tool_description": "Automatic SQL injection tool",
                "category":         "SQL Error Disclosure",
                "name":             "SQL error message visible in page response",
                "severity":         "critical",
                "what_hacker_sees": f"SQLMap detected SQL error: '{error}'. This confirms a database is behind this page.",
                "how_tool_attacks": "Visible SQL errors confirm injection points and reveal database type, structure, and sometimes data. SQLMap uses these as starting points.",
                "alert":            f"Your site displays SQL error messages publicly. This tells attackers exactly what database you're using and confirms SQL injection is possible.",
                "fix":              "Suppress ALL database errors from public view. Enable custom error pages. Never show raw exception details to users.",
            })
            break

    # ==============================================================
    #  4. BURP SUITE — Session and Request Interception
    # ==============================================================

    # IDOR — sequential integer IDs in URL
    if re.search(r"/\d+", url):
        findings.append({
            "tool":             "Burp Suite",
            "tool_description": "Web application security testing platform",
            "category":         "IDOR — Insecure Direct Object Reference",
            "name":             "Sequential integer ID found in URL — IDOR risk",
            "severity":         "high",
            "what_hacker_sees": "Burp Suite's scanner would flag the integer ID. An attacker can increment/decrement it to access other users' data.",
            "how_tool_attacks": "Burp Suite's Intruder tool automates changing URL parameters. It tries /user/1, /user/2, /user/3 to enumerate all user records.",
            "alert":            "Using sequential integers in URLs allows attackers to access other users' data by simply changing the number.",
            "fix":              "Replace integer IDs with UUIDs. Always verify on the server that the requesting user owns the requested resource.",
        })

    # Missing CSRF tokens on forms
    unprotected = [
        f for f in soup.find_all("form")
        if not f.find("input", attrs={"name": re.compile(r"csrf|token|_token", re.I)})
    ]
    if unprotected:
        findings.append({
            "tool":             "Burp Suite",
            "tool_description": "Web application security testing platform",
            "category":         "CSRF Vulnerability",
            "name":             f"{len(unprotected)} form(s) missing CSRF protection",
            "severity":         "high",
            "what_hacker_sees": "Burp Suite detects forms without CSRF tokens and generates attack payloads to trick logged-in users into submitting actions.",
            "how_tool_attacks": "Burp Suite's CSRF PoC generator creates a hidden form on an attacker's site. A victim visiting it submits your form using their active session.",
            "alert":            f"{len(unprotected)} form(s) have no CSRF protection. An attacker can make logged-in users perform actions without their knowledge.",
            "fix":              "Add a unique CSRF token to every state-changing form. Validate the token server-side before processing any submission.",
        })

    # ==============================================================
    #  5. OWASP ZAP — Full OWASP Top 10 Check
    # ==============================================================
    owasp_issues = []
    if not headers.get("Content-Security-Policy"):
        owasp_issues.append("A03:Injection (missing CSP allows XSS)")
    if not headers.get("Strict-Transport-Security"):
        owasp_issues.append("A02:Cryptographic Failures (no HSTS)")
    if not headers.get("X-Frame-Options"):
        owasp_issues.append("A05:Security Misconfiguration (clickjacking possible)")

    cdn_without_sri = [
        tag for tag in soup.find_all("script", src=True)
        if ("cdn" in tag.get("src", "") or "ajax.googleapis" in tag.get("src", ""))
        and not tag.get("integrity")
    ]
    if cdn_without_sri:
        owasp_issues.append(f"A08:Integrity Failures ({len(cdn_without_sri)} CDN script(s) missing SRI)")

    if owasp_issues:
        findings.append({
            "tool":             "OWASP ZAP",
            "tool_description": "Full OWASP Top 10 automated vulnerability scanner",
            "category":         "OWASP Top 10 Violations",
            "name":             f"{len(owasp_issues)} OWASP Top 10 violation(s) detected",
            "severity":         "high",
            "what_hacker_sees": f"OWASP ZAP flags: {'; '.join(owasp_issues)}",
            "how_tool_attacks": "ZAP systematically tests every OWASP category using active and passive scanning. Each violation is a documented attack vector with known exploits.",
            "alert":            f"Your site fails {len(owasp_issues)} OWASP Top 10 checks — the most common and most exploited web vulnerabilities worldwide.",
            "fix":              f"Address each: {'. '.join(owasp_issues)}. Follow the OWASP remediation guides at owasp.org.",
        })

    # ==============================================================
    #  6. ACUNETIX — Deep Crawl and LFI Detection
    # ==============================================================
    lfi_params = ["file", "page", "include", "path", "template", "doc", "folder"]
    if parsed.query:
        found_lfi = [
            p.split("=")[0] for p in parsed.query.split("&")
            if p.split("=")[0].lower() in lfi_params
        ]
        if found_lfi:
            findings.append({
                "tool":             "Acunetix",
                "tool_description": "Deep web vulnerability scanner with crawling and LFI testing",
                "category":         "Local File Inclusion (LFI) Risk",
                "name":             f"LFI-risk parameter(s) in URL: {', '.join(found_lfi)}",
                "severity":         "critical",
                "what_hacker_sees": f"Acunetix would immediately test '{', '.join(found_lfi)}' for LFI, attempting to read /etc/passwd and server config files.",
                "how_tool_attacks": "Acunetix sends payloads like ?file=../../etc/passwd to read files from the server filesystem.",
                "alert":            f"The parameter '{', '.join(found_lfi)}' is a classic LFI target. If vulnerable, an attacker can read any server file including passwords and SSH keys.",
                "fix":              "Never pass file paths as URL parameters. Use a whitelist of allowed files. Validate and sanitize all file path inputs strictly.",
            })

    # ==============================================================
    #  7. NESSUS — TLS/SSL and CVE Analysis
    # ==============================================================
    if parsed.scheme == "https":
        try:
            ctx  = ssl.create_default_context()
            conn = ctx.wrap_socket(socket.socket(), server_hostname=parsed.netloc)
            conn.settimeout(5)
            conn.connect((parsed.netloc, 443))
            tls_version = conn.version()
            conn.close()

            if tls_version in ("TLSv1", "TLSv1.1"):
                findings.append({
                    "tool":             "Nessus",
                    "tool_description": "Comprehensive vulnerability and CVE assessment scanner",
                    "category":         "Weak TLS Version",
                    "name":             f"Deprecated TLS version in use: {tls_version}",
                    "severity":         "critical",
                    "what_hacker_sees": f"Nessus flags {tls_version} as deprecated and tests for POODLE (CVE-2014-3566) and BEAST (CVE-2011-3389).",
                    "how_tool_attacks": f"Nessus tests for downgrade attacks. {tls_version} was deprecated in 2020 — attackers can force a downgrade and decrypt HTTPS traffic.",
                    "alert":            f"Your site uses {tls_version} which is deprecated. Attackers can decrypt HTTPS traffic and steal session cookies and user data.",
                    "fix":              "Disable TLS 1.0 and 1.1. Enable TLS 1.2 and 1.3 only. Test your config at ssllabs.com/ssltest/",
                })
        except Exception:
            pass

    # Known vulnerable JS libraries with CVEs
    js_cve_map = {
        re.compile(r"jquery[/-]1\.\d+", re.I):    ("jQuery 1.x",    "CVE-2015-9251, CVE-2019-11358"),
        re.compile(r"jquery[/-]2\.\d+", re.I):    ("jQuery 2.x",    "CVE-2019-11358"),
        re.compile(r"bootstrap[/-]3\.\d+", re.I): ("Bootstrap 3.x", "CVE-2019-8331"),
        re.compile(r"angular[/-]1\.\d+", re.I):   ("AngularJS 1.x", "CVE-2019-10768"),
    }
    for pat, (lib, cves) in js_cve_map.items():
        if pat.search(html):
            findings.append({
                "tool":             "Nessus",
                "tool_description": "Vulnerability and CVE assessment scanner",
                "category":         "Vulnerable JavaScript Library",
                "name":             f"Vulnerable library detected: {lib}",
                "severity":         "medium",
                "what_hacker_sees": f"Nessus matches {lib} against its CVE database: {cves}.",
                "how_tool_attacks": "Nessus cross-references detected software versions against the NVD CVE database and generates PoC exploit code for confirmed vulnerable versions.",
                "alert":            f"Your site loads {lib} which has known CVEs: {cves}. Attackers can exploit these without any special access.",
                "fix":              f"Update {lib} to the latest stable version immediately. Run npm audit regularly to catch vulnerable dependencies.",
            })

    # ==============================================================
    #  8. OPENVAS — CORS and Configuration Audit
    # ==============================================================
    cors_header = headers.get("Access-Control-Allow-Origin", "")
    if cors_header == "*":
        findings.append({
            "tool":             "OpenVAS",
            "tool_description": "Comprehensive network and web vulnerability assessment system",
            "category":         "CORS Misconfiguration",
            "name":             "Wildcard CORS policy (Access-Control-Allow-Origin: *)",
            "severity":         "critical",
            "what_hacker_sees": "OpenVAS flags wildcard CORS. Any website can make authenticated requests to your API and read the responses.",
            "how_tool_attacks": "With wildcard CORS, a malicious site can use a victim's browser to call your API endpoints and steal data including scan results and user info.",
            "alert":            "Your API accepts requests from ANY website. An attacker can steal private user data by hosting a malicious page that silently calls your API.",
            "fix":              "Replace 'Access-Control-Allow-Origin: *' with your specific frontend domain. Never use wildcard CORS on authenticated APIs.",
        })

    # Exposed debug/dev endpoints
    debug_paths = ["/debug", "/test", "/dev", "/api/debug",
                   "/console", "/actuator", "/actuator/env", "/_profiler"]
    for path in debug_paths:
        resp = _get(base + path)
        if resp and resp.status_code in (200, 302):
            findings.append({
                "tool":             "OpenVAS",
                "tool_description": "Network and web vulnerability assessment system",
                "category":         "Exposed Debug Endpoint",
                "name":             f"Debug/development endpoint accessible: {path}",
                "severity":         "critical",
                "what_hacker_sees": f"OpenVAS found {path} accessible. This endpoint may expose server internals, environment variables, and application state.",
                "how_tool_attacks": "OpenVAS probes hundreds of known debug and admin paths. Debug endpoints often expose configuration, memory state, and full execution environment.",
                "alert":            f"The debug endpoint '{path}' is publicly accessible. Debug interfaces expose environment variables, DB connections, and full application configuration.",
                "fix":              f"Disable or remove '{path}' in production. Use environment-based config to ensure debug tools are never available in production.",
            })

    return findings
